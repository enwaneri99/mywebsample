---
name: Shared notes ownership
description: Why database-backed notes are currently shared and what must change before multi-user use.
---

Database-backed notes are intentionally shared across the project; there is no user ownership boundary yet.

**Why:** The database migration was scoped without authentication, accounts, or permissions, so pretending notes are private would create a security and product mismatch.

**How to apply:** Treat the current app as single-user or trusted-demo software. Before exposing it to multiple users, add authentication, an owner identifier, and ownership filters to every notes query and mutation.