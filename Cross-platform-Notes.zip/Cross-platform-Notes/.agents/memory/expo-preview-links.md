---
name: Expo preview links
description: The distinction between Expo Go deep links and browser-safe mobile preview URLs.
---

Expo development URLs use the `exp://` scheme for Expo Go. Safari, Chrome, and desktop browsers should use the same host with `https://` instead. The mobile landing page no longer exposes either preview link.

**Why:** The Expo packager intentionally emits a deep link, so opening or pasting it into a browser produces an unsupported-protocol error even when the app and server are healthy.

**How to apply:** Direct users to the Replit mobile preview controls for development. Keep the published landing page free of generated preview URLs; use the HTTPS Expo preview URL only when browser inspection is explicitly needed.