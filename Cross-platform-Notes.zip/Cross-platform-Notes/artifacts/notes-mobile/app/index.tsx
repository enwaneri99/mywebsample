import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import React, { useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Keyboard,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';
import { Note, NotesProvider, useNotes } from '@/context/NotesContext';

function formatDate(dateString: string) {
  const date = new Date(dateString);
  const today = new Date();
  if (date.toDateString() === today.toDateString()) {
    return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  }
  return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

function notePreview(note: Note) {
  return note.content.replace(/\n/g, ' ').trim() || 'Start writing something worth keeping…';
}

function HomeScreen({
  onOpenNote,
}: {
  onOpenNote: (id: string) => void;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { notes, createNote, togglePinned, syncState, retry } = useNotes();
  const [search, setSearch] = useState('');
  const [activeFolder, setActiveFolder] = useState('All notes');

  const folders = useMemo(
    () => ['All notes', ...Array.from(new Set(notes.map((note) => note.folder)))],
    [notes],
  );
  const filteredNotes = useMemo(() => {
    const query = search.trim().toLowerCase();
    return [...notes]
      .filter((note) => activeFolder === 'All notes' || note.folder === activeFolder)
      .filter(
        (note) =>
          !query ||
          note.title.toLowerCase().includes(query) ||
          note.content.toLowerCase().includes(query) ||
          note.tags.some((tag) => tag.toLowerCase().includes(query)),
      )
      .sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt.localeCompare(a.updatedAt));
  }, [notes, search, activeFolder]);

  const handleNew = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    onOpenNote(createNote().id);
  };

  if (!notes.length) {
    return (
      <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: insets.top }]}>
        <View style={styles.header}>
          <Text style={[styles.wordmark, { color: colors.foreground }]}>Notes</Text>
          <Pressable onPress={handleNew} style={[styles.headerIcon, { backgroundColor: colors.primary }]}>
            <Feather name="plus" size={22} color={colors.primaryForeground} />
          </Pressable>
        </View>
        <View style={styles.emptyState}>
          <View style={[styles.emptyIcon, { backgroundColor: colors.accent }]}>
            <Feather name="edit-3" size={28} color={colors.secondaryForeground} />
          </View>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Make space for an idea</Text>
          <Text style={[styles.emptyBody, { color: colors.mutedForeground }]}>
            Your notes will live here, ready whenever inspiration finds you.
          </Text>
          <Pressable onPress={handleNew} style={[styles.primaryButton, { backgroundColor: colors.primary }]}>
            <Text style={styles.primaryButtonText}>Write a note</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: insets.top }]}>
      <View style={styles.header}>
        <View>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>Your quiet corner</Text>
          <Text style={[styles.wordmark, { color: colors.foreground }]}>Notes</Text>
        </View>
        <Pressable
          accessibilityLabel="Create a new note"
          testID="new-note-button"
          onPress={handleNew}
          style={({ pressed }) => [
            styles.headerIcon,
            { backgroundColor: colors.primary, opacity: pressed ? 0.75 : 1 },
          ]}
        >
          <Feather name="plus" size={22} color={colors.primaryForeground} />
        </Pressable>
      </View>

      {syncState !== 'synced' ? (
        <Pressable
          accessibilityRole="button"
          onPress={syncState === 'offline' ? retry : undefined}
          style={[styles.syncBanner, { backgroundColor: colors.accent }]}
        >
          <Feather
            name={syncState === 'offline' ? 'wifi-off' : 'refresh-cw'}
            size={14}
            color={colors.secondaryForeground}
          />
          <Text style={[styles.syncBannerText, { color: colors.secondaryForeground }]}>
            {syncState === 'offline'
              ? 'Offline — showing saved notes. Tap to reconnect.'
              : 'Syncing with the database…'}
          </Text>
        </Pressable>
      ) : null}

      <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Feather name="search" size={18} color={colors.mutedForeground} />
        <TextInput
          accessibilityLabel="Search notes"
          testID="search-notes"
          value={search}
          onChangeText={setSearch}
          placeholder="Search your notes"
          placeholderTextColor={colors.mutedForeground}
          style={[styles.searchInput, { color: colors.foreground }]}
          returnKeyType="search"
        />
        {search ? (
          <Pressable onPress={() => setSearch('')} hitSlop={10}>
            <Feather name="x-circle" size={17} color={colors.mutedForeground} />
          </Pressable>
        ) : null}
      </View>

      <FlatList
        data={filteredNotes}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        scrollEnabled={filteredNotes.length > 0}
        contentContainerStyle={[styles.listContent, { paddingBottom: insets.bottom + 104 }]}
        ListHeaderComponent={
          <View>
            <FlatList
              data={folders}
              horizontal
              showsHorizontalScrollIndicator={false}
              keyExtractor={(item) => item}
              contentContainerStyle={styles.folderRow}
              renderItem={({ item }) => (
                <Pressable
                  onPress={() => setActiveFolder(item)}
                  style={[
                    styles.folderChip,
                    {
                      backgroundColor: activeFolder === item ? colors.secondaryForeground : colors.card,
                      borderColor: activeFolder === item ? colors.secondaryForeground : colors.border,
                    },
                  ]}
                >
                  <Text
                    style={[
                      styles.folderText,
                      { color: activeFolder === item ? colors.primaryForeground : colors.mutedForeground },
                    ]}
                  >
                    {item}
                  </Text>
                </Pressable>
              )}
            />
            <View style={styles.listHeading}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
                {search ? 'Search results' : activeFolder === 'All notes' ? 'Recently written' : activeFolder}
              </Text>
              <Text style={[styles.noteCount, { color: colors.mutedForeground }]}>
                {filteredNotes.length} {filteredNotes.length === 1 ? 'note' : 'notes'}
              </Text>
            </View>
          </View>
        }
        ListEmptyComponent={
          <View style={styles.noResults}>
            <Feather name="wind" size={24} color={colors.mutedForeground} />
            <Text style={[styles.noResultsText, { color: colors.mutedForeground }]}>Nothing matches that search.</Text>
          </View>
        }
        renderItem={({ item }) => (
          <Pressable
            testID={`note-card-${item.id}`}
            onPress={() => {
              Keyboard.dismiss();
              onOpenNote(item.id);
            }}
            style={({ pressed }) => [
              styles.noteCard,
              { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.76 : 1 },
            ]}
          >
            <View style={styles.noteCardTop}>
              <Text numberOfLines={1} style={[styles.noteTitle, { color: colors.foreground }]}>
                {item.title || 'Untitled note'}
              </Text>
              <Pressable
                accessibilityLabel={item.pinned ? 'Unpin note' : 'Pin note'}
                onPress={() => {
                  Haptics.selectionAsync();
                  togglePinned(item.id);
                }}
                hitSlop={12}
              >
                <Feather name="bookmark" size={17} color={item.pinned ? colors.primary : colors.mutedForeground} />
              </Pressable>
            </View>
            <Text numberOfLines={2} style={[styles.notePreview, { color: colors.mutedForeground }]}>
              {notePreview(item)}
            </Text>
            <View style={styles.noteMeta}>
              <Text style={[styles.noteFolder, { color: colors.secondaryForeground }]}>{item.folder}</Text>
              <Text style={[styles.noteDate, { color: colors.mutedForeground }]}>{formatDate(item.updatedAt)}</Text>
            </View>
          </Pressable>
        )}
      />
      <Pressable
        accessibilityLabel="Create a new note"
        onPress={handleNew}
        style={({ pressed }) => [
          styles.fab,
          { backgroundColor: colors.primary, bottom: insets.bottom + 22, opacity: pressed ? 0.78 : 1 },
        ]}
      >
        <Feather name="edit-3" size={20} color={colors.primaryForeground} />
        <Text style={styles.fabText}>New note</Text>
      </Pressable>
    </View>
  );
}

function EditorScreen({ noteId, onClose }: { noteId: string; onClose: () => void }) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { notes, updateNote, deleteNote, togglePinned } = useNotes();
  const note = notes.find((item) => item.id === noteId);

  if (!note) {
    onClose();
    return null;
  }

  const confirmDelete = () => {
    const removeNote = () => {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      deleteNote(note.id);
      onClose();
    };

    if (Platform.OS === 'web') {
      if (window.confirm('Delete this note? This cannot be undone.')) {
        removeNote();
      }
      return;
    }

    Alert.alert('Delete this note?', 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: removeNote,
      },
    ]);
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: insets.top }]}>
      <View style={styles.editorToolbar}>
        <Pressable
          accessibilityLabel="Back to notes"
          onPress={onClose}
          hitSlop={10}
          style={styles.toolbarButton}
        >
          <Feather name="chevron-left" size={25} color={colors.foreground} />
          <Text style={[styles.backText, { color: colors.foreground }]}>Notes</Text>
        </Pressable>
        <View style={styles.toolbarActions}>
          <Pressable
            accessibilityLabel={note.pinned ? 'Unpin note' : 'Pin note'}
            onPress={() => togglePinned(note.id)}
            hitSlop={10}
            style={styles.toolbarButton}
          >
            <Feather name="bookmark" size={20} color={note.pinned ? colors.primary : colors.mutedForeground} />
          </Pressable>
          <Pressable accessibilityLabel="Delete note" onPress={confirmDelete} hitSlop={10} style={styles.toolbarButton}>
            <Feather name="trash-2" size={19} color={colors.destructive} />
          </Pressable>
        </View>
      </View>
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={[styles.editorContent, { paddingBottom: insets.bottom + 50 }]}
        showsVerticalScrollIndicator={false}
        bottomOffset={24}
      >
        <TextInput
          accessibilityLabel="Note title"
          testID="note-title-input"
          value={note.title}
          onChangeText={(title) => updateNote(note.id, { title })}
          placeholder="Untitled note"
          placeholderTextColor={colors.mutedForeground}
          style={[styles.titleInput, { color: colors.foreground }]}
          selectionColor={colors.primary}
        />
        <View style={styles.editorMetaRow}>
          <View style={[styles.folderBadge, { backgroundColor: colors.accent }]}>
            <Feather name="folder" size={13} color={colors.secondaryForeground} />
            <TextInput
              accessibilityLabel="Note folder"
              value={note.folder}
              onChangeText={(folder) => updateNote(note.id, { folder: folder || 'Personal' })}
              style={[styles.folderInput, { color: colors.secondaryForeground }]}
              placeholder="Folder"
              placeholderTextColor={colors.secondaryForeground}
              selectTextOnFocus
            />
          </View>
          <Text style={[styles.savedLabel, { color: colors.mutedForeground }]}>Saved {formatDate(note.updatedAt)}</Text>
        </View>
        <TextInput
          accessibilityLabel="Note body"
          testID="note-body-input"
          multiline
          value={note.content}
          onChangeText={(content) => updateNote(note.id, { content })}
          placeholder="Begin with a thought…"
          placeholderTextColor={colors.mutedForeground}
          style={[styles.bodyInput, { color: colors.foreground }]}
          textAlignVertical="top"
          selectionColor={colors.primary}
        />
        <View style={styles.tagSection}>
          <Text style={[styles.tagLabel, { color: colors.mutedForeground }]}>Tags</Text>
          <TextInput
            accessibilityLabel="Note tags"
            value={note.tags.join(', ')}
            onChangeText={(value) =>
              updateNote(note.id, {
                tags: value
                  .split(',')
                  .map((tag) => tag.trim().toLowerCase())
                  .filter(Boolean),
              })
            }
            placeholder="Add tags, separated by commas"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.tagsInput, { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground }]}
            returnKeyType="done"
            onSubmitEditing={() => Keyboard.dismiss()}
          />
        </View>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

function NotesApp() {
  const colors = useColors();
  const { isReady } = useNotes();
  const [openNoteId, setOpenNoteId] = useState<string | null>(null);

  if (!isReady) {
    return (
      <View style={[styles.loading, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  return openNoteId ? (
    <EditorScreen noteId={openNoteId} onClose={() => setOpenNoteId(null)} />
  ) : (
    <HomeScreen onOpenNote={setOpenNoteId} />
  );
}

export default function Index() {
  return (
    <NotesProvider>
      <NotesApp />
    </NotesProvider>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: {
    minHeight: 104,
    paddingHorizontal: 22,
    paddingTop: 20,
    paddingBottom: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  eyebrow: { fontFamily: 'Inter_600SemiBold', fontSize: 12, letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 5 },
  wordmark: { fontFamily: 'Inter_700Bold', fontSize: 34, letterSpacing: -1.1 },
  headerIcon: { width: 44, height: 44, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  searchBox: {
    height: 48,
    marginHorizontal: 18,
    borderRadius: 15,
    borderWidth: 1,
    paddingHorizontal: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  syncBanner: {
    marginHorizontal: 18,
    marginBottom: 4,
    borderRadius: 12,
    paddingHorizontal: 13,
    paddingVertical: 9,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  syncBannerText: { flex: 1, fontFamily: 'Inter_500Medium', fontSize: 12 },
  searchInput: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 15, paddingVertical: 0 },
  listContent: { paddingTop: 12, paddingHorizontal: 18 },
  folderRow: { gap: 8, paddingVertical: 8 },
  folderChip: { borderRadius: 20, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 8 },
  folderText: { fontFamily: 'Inter_500Medium', fontSize: 13 },
  listHeading: { flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between', paddingTop: 17, paddingBottom: 12 },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 20, letterSpacing: -0.3 },
  noteCount: { fontFamily: 'Inter_400Regular', fontSize: 13 },
  noteCard: { borderRadius: 17, borderWidth: 1, padding: 16, marginBottom: 10 },
  noteCardTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  noteTitle: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 16, letterSpacing: -0.2 },
  notePreview: { fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 21, marginTop: 8 },
  noteMeta: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 15 },
  noteFolder: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  noteDate: { fontFamily: 'Inter_400Regular', fontSize: 12 },
  fab: { position: 'absolute', right: 20, borderRadius: 22, paddingHorizontal: 17, height: 48, flexDirection: 'row', alignItems: 'center', gap: 9, shadowColor: '#173B3F', shadowOpacity: 0.18, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 5 },
  fabText: { color: '#FFFDF9', fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  noResults: { alignItems: 'center', paddingVertical: 50, gap: 10 },
  noResultsText: { fontFamily: 'Inter_400Regular', fontSize: 14 },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 42, marginTop: -70 },
  emptyIcon: { width: 72, height: 72, borderRadius: 26, alignItems: 'center', justifyContent: 'center', marginBottom: 18 },
  emptyTitle: { fontFamily: 'Inter_700Bold', fontSize: 23, letterSpacing: -0.5, textAlign: 'center' },
  emptyBody: { fontFamily: 'Inter_400Regular', fontSize: 15, lineHeight: 22, textAlign: 'center', marginTop: 9, maxWidth: 280 },
  primaryButton: { borderRadius: 15, paddingHorizontal: 20, paddingVertical: 13, marginTop: 23 },
  primaryButtonText: { color: '#FFFDF9', fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  editorToolbar: { height: 60, paddingHorizontal: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  toolbarButton: { flexDirection: 'row', alignItems: 'center', gap: 2 },
  toolbarActions: { flexDirection: 'row', alignItems: 'center', gap: 22 },
  backText: { fontFamily: 'Inter_500Medium', fontSize: 15 },
  editorContent: { paddingHorizontal: 22, paddingTop: 14 },
  titleInput: { fontFamily: 'Inter_700Bold', fontSize: 30, letterSpacing: -0.9, paddingVertical: 5 },
  editorMetaRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 12, marginBottom: 18 },
  folderBadge: { borderRadius: 13, paddingHorizontal: 10, paddingVertical: 6, flexDirection: 'row', alignItems: 'center', gap: 6 },
  folderInput: { fontFamily: 'Inter_500Medium', fontSize: 12, minWidth: 70, padding: 0 },
  savedLabel: { fontFamily: 'Inter_400Regular', fontSize: 12 },
  bodyInput: { minHeight: 300, fontFamily: 'Inter_400Regular', fontSize: 17, lineHeight: 28, paddingVertical: 2 },
  tagSection: { marginTop: 20 },
  tagLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 12, textTransform: 'uppercase', letterSpacing: 1.2, marginBottom: 8 },
  tagsInput: { borderWidth: 1, borderRadius: 13, paddingHorizontal: 13, paddingVertical: 11, fontFamily: 'Inter_400Regular', fontSize: 13 },
});