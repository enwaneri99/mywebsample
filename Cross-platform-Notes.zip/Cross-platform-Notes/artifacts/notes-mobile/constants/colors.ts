/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#173B3F',
    tint: '#E8785A',

    // Core surfaces
    background: '#F7F2EA',
    foreground: '#173B3F',

    // Cards / elevated surfaces
    card: '#FFFDF9',
    cardForeground: '#173B3F',

    // Primary action color (buttons, links, active states)
    primary: '#E8785A',
    primaryForeground: '#ffffff',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#E4ECE5',
    secondaryForeground: '#24545A',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#E9E3D9',
    mutedForeground: '#728482',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#D9E8DE',
    accentForeground: '#24545A',

    // Destructive actions (delete, error states)
    destructive: '#C95545',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#DDD8CF',
    input: '#D5D0C6',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 14,
};

export default colors;
