import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  createNote as createNoteRequest,
  deleteNote as deleteNoteRequest,
  listNotes,
  setBaseUrl,
  type Note,
  type NoteUpdate,
  updateNote as updateNoteRequest,
} from '@workspace/api-client-react';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';

export type { Note };

type SyncState = 'syncing' | 'synced' | 'offline';

type NotesContextValue = {
  notes: Note[];
  isReady: boolean;
  syncState: SyncState;
  retry: () => void;
  createNote: () => Note;
  updateNote: (id: string, changes: Partial<Note>) => void;
  deleteNote: (id: string) => void;
  togglePinned: (id: string) => void;
};

const STORAGE_KEY = '@notes-mobile/notes';
const MIGRATION_KEY = '@notes-mobile/database-migrated-v1';
const publicDomain = process.env.EXPO_PUBLIC_DOMAIN?.trim();

if (publicDomain) {
  const normalizedDomain = publicDomain.replace(/^https?:\/\//, '').replace(/\/+$/, '');
  setBaseUrl(`https://${normalizedDomain}`);
}

const starterNotes: Note[] = [
  {
    id: 'welcome',
    title: 'A place for your thoughts',
    content:
      'Capture the little things before they float away.\n\nThis is your quiet corner for ideas, lists, and everything in between.',
    folder: 'Personal',
    tags: ['welcome'],
    pinned: true,
    createdAt: '2026-08-26T09:30:00.000Z',
    updatedAt: '2026-08-26T09:30:00.000Z',
  },
  {
    id: 'weekend',
    title: 'Weekend ideas',
    content:
      '• Walk the lakeside trail\n• Try the new bakery on 5th\n• Call Mum Sunday morning',
    folder: 'Personal',
    tags: ['ideas'],
    pinned: false,
    createdAt: '2026-08-24T15:10:00.000Z',
    updatedAt: '2026-08-25T08:45:00.000Z',
  },
  {
    id: 'reading',
    title: 'Books to return to',
    content:
      'The creative act is not about waiting for inspiration. It is about making room for it.',
    folder: 'Reading',
    tags: ['books', 'quotes'],
    pinned: false,
    createdAt: '2026-08-20T12:00:00.000Z',
    updatedAt: '2026-08-20T12:00:00.000Z',
  },
];

const NotesContext = createContext<NotesContextValue | null>(null);

function makeId() {
  return `${Date.now().toString()}${Math.random().toString(36).slice(2, 8)}`;
}

function parseCachedNotes(value: string | null): Note[] {
  if (!value) return [];
  try {
    const parsed = JSON.parse(value) as unknown;
    return Array.isArray(parsed) ? (parsed as Note[]) : [];
  } catch {
    return [];
  }
}

export function NotesProvider({ children }: { children: React.ReactNode }) {
  const [notes, setNotes] = useState<Note[]>([]);
  const [isReady, setIsReady] = useState(false);
  const [syncState, setSyncState] = useState<SyncState>('syncing');
  const notesRef = useRef<Note[]>([]);
  const updateTimers = useRef<Record<string, ReturnType<typeof setTimeout>>>({});
  const updateRevisions = useRef<Record<string, number>>({});

  const replaceNotes = useCallback((nextNotes: Note[]) => {
    notesRef.current = nextNotes;
    setNotes(nextNotes);
  }, []);

  const loadNotes = useCallback(async () => {
    setSyncState('syncing');
    const stored = await AsyncStorage.getItem(STORAGE_KEY).catch(() => null);
    const cachedNotes = parseCachedNotes(stored);

    try {
      const serverNotes = await listNotes();
      const migrationDone = await AsyncStorage.getItem(MIGRATION_KEY);
      if (!migrationDone && cachedNotes.length > 0) {
        const serverIds = new Set(serverNotes.map((note) => note.id));
        const missingNotes = cachedNotes.filter((note) => !serverIds.has(note.id));
        const results = await Promise.allSettled(
          missingNotes.map((note) =>
            createNoteRequest({
              id: note.id,
              title: note.title,
              content: note.content,
              folder: note.folder,
              tags: note.tags,
              pinned: note.pinned,
            }),
          ),
        );
        if (results.every((result) => result.status === 'fulfilled')) {
          await AsyncStorage.setItem(MIGRATION_KEY, 'done');
        }
        replaceNotes(missingNotes.length ? await listNotes() : serverNotes);
      } else {
        replaceNotes(serverNotes);
      }
      setSyncState('synced');
    } catch {
      replaceNotes(cachedNotes.length ? cachedNotes : starterNotes);
      setSyncState('offline');
    } finally {
      setIsReady(true);
    }
  }, [replaceNotes]);

  useEffect(() => {
    loadNotes();
    return () => {
      Object.values(updateTimers.current).forEach(clearTimeout);
    };
  }, [loadNotes]);

  useEffect(() => {
    if (!isReady) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(notes)).catch(() => undefined);
  }, [isReady, notes]);

  const createNote = useCallback(() => {
    const now = new Date().toISOString();
    const newNote: Note = {
      id: makeId(),
      title: '',
      content: '',
      folder: 'Personal',
      tags: [],
      pinned: false,
      createdAt: now,
      updatedAt: now,
    };
    replaceNotes([newNote, ...notesRef.current]);
    createNoteRequest({
      id: newNote.id,
      title: newNote.title,
      content: newNote.content,
      folder: newNote.folder,
      tags: newNote.tags,
      pinned: newNote.pinned,
    })
      .then((savedNote) => {
        replaceNotes(
          notesRef.current.map((note) => (note.id === savedNote.id ? savedNote : note)),
        );
        setSyncState('synced');
      })
      .catch(() => {
        AsyncStorage.removeItem(MIGRATION_KEY).catch(() => undefined);
        setSyncState('offline');
      });
    return newNote;
  }, [replaceNotes]);

  const updateNote = useCallback((id: string, changes: Partial<Note>) => {
    const revision = (updateRevisions.current[id] ?? 0) + 1;
    updateRevisions.current[id] = revision;
    const nextNotes = notesRef.current.map((note) =>
      note.id === id
        ? { ...note, ...changes, updatedAt: new Date().toISOString() }
        : note,
    );
    replaceNotes(nextNotes);
    setSyncState('syncing');

    clearTimeout(updateTimers.current[id]);
    updateTimers.current[id] = setTimeout(() => {
      const currentNote = notesRef.current.find((note) => note.id === id);
      if (!currentNote) return;
      const data: NoteUpdate = {
        title: currentNote.title,
        content: currentNote.content,
        folder: currentNote.folder,
        tags: currentNote.tags,
        pinned: currentNote.pinned,
      };

      updateNoteRequest(id, data)
        .then((savedNote) => {
          if (updateRevisions.current[id] !== revision) return;
          replaceNotes(
            notesRef.current.map((note) => (note.id === id ? savedNote : note)),
          );
          setSyncState('synced');
        })
        .catch(() => setSyncState('offline'));
    }, 500);
  }, [replaceNotes]);

  const deleteNote = useCallback((id: string) => {
    clearTimeout(updateTimers.current[id]);
    delete updateTimers.current[id];
    delete updateRevisions.current[id];
    const previousNotes = notesRef.current;
    replaceNotes(previousNotes.filter((note) => note.id !== id));
    deleteNoteRequest(id)
      .then(() => setSyncState('synced'))
      .catch(() => {
        replaceNotes(previousNotes);
        setSyncState('offline');
      });
  }, [replaceNotes]);

  const togglePinned = useCallback((id: string) => {
    const note = notesRef.current.find((item) => item.id === id);
    if (note) updateNote(id, { pinned: !note.pinned });
  }, [updateNote]);

  const value = useMemo(
    () => ({
      notes,
      isReady,
      syncState,
      retry: () => loadNotes(),
      createNote,
      updateNote,
      deleteNote,
      togglePinned,
    }),
    [notes, isReady, syncState, loadNotes, createNote, updateNote, deleteNote, togglePinned],
  );

  return <NotesContext.Provider value={value}>{children}</NotesContext.Provider>;
}

export function useNotes() {
  const value = useContext(NotesContext);
  if (!value) throw new Error('useNotes must be used inside NotesProvider');
  return value;
}