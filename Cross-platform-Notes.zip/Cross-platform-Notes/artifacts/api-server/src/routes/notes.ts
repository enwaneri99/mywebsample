import { desc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  CreateNoteBody,
  CreateNoteResponse,
  DeleteNoteParams,
  GetNoteParams,
  GetNoteResponse,
  ListNotesResponse,
  UpdateNoteBody,
  UpdateNoteParams,
  UpdateNoteResponse,
} from "@workspace/api-zod";
import { db, notesTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/notes", async (_req, res): Promise<void> => {
  const notes = await db
    .select()
    .from(notesTable)
    .orderBy(desc(notesTable.updatedAt), desc(notesTable.createdAt));

  res.json(ListNotesResponse.parse(notes));
});

router.post("/notes", async (req, res): Promise<void> => {
  const parsed = CreateNoteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [note] = await db
    .insert(notesTable)
    .values(parsed.data)
    .onConflictDoNothing({ target: notesTable.id })
    .returning();

  if (!note) {
    res.status(409).json({ error: "A note with this id already exists" });
    return;
  }

  res.status(201).json(CreateNoteResponse.parse(note));
});

router.get("/notes/:id", async (req, res): Promise<void> => {
  const parsed = GetNoteParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [note] = await db
    .select()
    .from(notesTable)
    .where(eq(notesTable.id, parsed.data.id));

  if (!note) {
    res.status(404).json({ error: "Note not found" });
    return;
  }

  res.json(GetNoteResponse.parse(note));
});

router.patch("/notes/:id", async (req, res): Promise<void> => {
  const params = UpdateNoteParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateNoteBody.safeParse(req.body);
  if (!parsed.success || Object.keys(parsed.data).length === 0) {
    res.status(400).json({
      error: parsed.success ? "At least one note field is required" : parsed.error.message,
    });
    return;
  }

  const [note] = await db
    .update(notesTable)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(eq(notesTable.id, params.data.id))
    .returning();

  if (!note) {
    res.status(404).json({ error: "Note not found" });
    return;
  }

  res.json(UpdateNoteResponse.parse(note));
});

router.delete("/notes/:id", async (req, res): Promise<void> => {
  const parsed = DeleteNoteParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [note] = await db
    .delete(notesTable)
    .where(eq(notesTable.id, parsed.data.id))
    .returning({ id: notesTable.id });

  if (!note) {
    res.status(404).json({ error: "Note not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;