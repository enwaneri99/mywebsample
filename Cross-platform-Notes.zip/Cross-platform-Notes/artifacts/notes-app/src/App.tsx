import { useCallback, useEffect, useMemo, useRef, useState, type Dispatch, type ReactNode, type SetStateAction } from 'react';
import {
  Archive,
  ArrowLeft,
  BookOpen,
  ChevronDown,
  FileText,
  Folder,
  Hash,
  Lightbulb,
  Menu,
  MoreHorizontal,
  Pin,
  Plus,
  Search,
  Settings2,
  Trash2,
  X,
} from 'lucide-react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  getListNotesQueryKey,
  type Note,
  useCreateNote,
  useDeleteNote,
  useListNotes,
  useUpdateNote,
} from '@workspace/api-client-react';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';

const STORAGE_KEY = 'quiet-notes-v1';
const MIGRATION_KEY = 'quiet-notes-database-migrated-v1';
const DEFAULT_FOLDERS = ['Inbox', 'Ideas', 'Journal', 'Work'];
const DEFAULT_TAGS = ['reading', 'project', 'personal'];

const makeId = () =>
  typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID()
    : `note-${Date.now()}-${Math.random().toString(16).slice(2)}`;

const formatDate = (value: string) => {
  const date = new Date(value);
  const now = new Date();
  const sameDay = date.toDateString() === now.toDateString();
  if (sameDay) {
    return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  }
  return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
};

const getPreview = (content: string) =>
  content.replace(/\s+/g, ' ').trim() || 'A blank page, waiting for a thought.';

const readLocalNotes = (): Note[] => {
  if (typeof window === 'undefined') return [];
  try {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (!stored) return [];
    const parsed = JSON.parse(stored) as Note[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

const IconButton = ({
  label,
  onClick,
  children,
  active = false,
  className = '',
}: {
  label: string;
  onClick: () => void;
  children: ReactNode;
  active?: boolean;
  className?: string;
}) => (
  <button
    type="button"
    aria-label={label}
    title={label}
    data-testid={`button-${label.toLowerCase().replace(/\s+/g, '-')}`}
    onClick={onClick}
    className={`inline-flex h-9 w-9 items-center justify-center rounded-lg transition-all duration-200 hover-elevate active-elevate ${
      active ? 'bg-[hsl(var(--accent)/.18)] text-[hsl(var(--accent))]' : 'text-current'
    } ${className}`}
  >
    {children}
  </button>
);

function NotesApp() {
  const notesQuery = useListNotes({
    query: {
      queryKey: getListNotesQueryKey(),
      staleTime: 15_000,
      refetchOnWindowFocus: true,
    },
  });
  const createMutation = useCreateNote();
  const updateMutation = useUpdateNote();
  const deleteMutation = useDeleteNote();
  const [notes, setNotes] = useState<Note[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [folder, setFolder] = useState('All notes');
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [draft, setDraft] = useState<Pick<Note, 'title' | 'content' | 'folder' | 'tags'>>({
    title: '',
    content: '',
    folder: 'Inbox',
    tags: [],
  });
  const [saveState, setSaveState] = useState<'saved' | 'saving' | 'error'>('saved');
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [mobileView, setMobileView] = useState<'list' | 'editor'>('list');
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);
  const draftReady = useRef(false);
  const migrationStarted = useRef(false);

  const syncNotes = useCallback((nextNotes: Note[]) => {
    setNotes(nextNotes);
    queryClient.setQueryData(getListNotesQueryKey(), nextNotes);
  }, []);

  useEffect(() => {
    if (!notesQuery.data) return;
    setNotes(notesQuery.data);
    setSelectedId((current) =>
      current && notesQuery.data.some((note) => note.id === current)
        ? current
        : notesQuery.data[0]?.id ?? null,
    );
    setConnectionError(null);
  }, [notesQuery.data]);

  useEffect(() => {
    if (!notesQuery.data || migrationStarted.current) return;
    migrationStarted.current = true;
    if (window.localStorage.getItem(MIGRATION_KEY)) return;

    const serverIds = new Set(notesQuery.data.map((note) => note.id));
    const missingLocalNotes = readLocalNotes().filter((note) => !serverIds.has(note.id));
    if (!missingLocalNotes.length) {
      window.localStorage.setItem(MIGRATION_KEY, 'done');
      return;
    }

    Promise.allSettled(
      missingLocalNotes.map((note) =>
        createMutation.mutateAsync({
          data: {
            id: note.id,
            title: note.title,
            content: note.content,
            folder: note.folder,
            tags: note.tags,
            pinned: note.pinned,
          },
        }),
      ),
    ).then((results) => {
      if (results.every((result) => result.status === 'fulfilled')) {
        window.localStorage.setItem(MIGRATION_KEY, 'done');
      }
      queryClient.invalidateQueries({ queryKey: getListNotesQueryKey() });
    });
  }, [createMutation, notesQuery.data]);

  const selectedNote = useMemo(
    () => notes.find((note) => note.id === selectedId) ?? null,
    [notes, selectedId],
  );

  const folders = useMemo(() => {
    const discovered = notes.map((note) => note.folder).filter(Boolean);
    return Array.from(new Set([...DEFAULT_FOLDERS, ...discovered]));
  }, [notes]);

  const tags = useMemo(() => {
    const discovered = notes.flatMap((note) => note.tags);
    return Array.from(new Set([...DEFAULT_TAGS, ...discovered]));
  }, [notes]);

  const filteredNotes = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();
    return [...notes]
      .filter((note) => {
        const matchesFolder = folder === 'All notes' || note.folder === folder || (folder === 'Pinned' && note.pinned);
        const matchesTag = !activeTag || note.tags.includes(activeTag);
        const haystack = `${note.title} ${note.content} ${note.tags.join(' ')}`.toLowerCase();
        return matchesFolder && matchesTag && (!normalizedQuery || haystack.includes(normalizedQuery));
      })
      .sort((a, b) => Number(b.pinned) - Number(a.pinned) || +new Date(b.updatedAt) - +new Date(a.updatedAt));
  }, [activeTag, folder, notes, query]);

  useEffect(() => {
    if (!selectedNote) {
      draftReady.current = false;
      return;
    }
    draftReady.current = false;
    setDraft({
      title: selectedNote.title,
      content: selectedNote.content,
      folder: selectedNote.folder,
      tags: selectedNote.tags,
    });
    const timer = window.setTimeout(() => {
      draftReady.current = true;
    }, 0);
    return () => window.clearTimeout(timer);
  }, [selectedId]); // Rehydrate only when changing notes, not when autosave updates the list.

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        searchRef.current?.focus();
      }
      if (event.key === 'Escape' && mobileNavOpen) setMobileNavOpen(false);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [mobileNavOpen]);

  useEffect(() => {
    if (!selectedId || !draftReady.current) return;
    const original = notes.find((note) => note.id === selectedId);
    if (
      original &&
      original.title === draft.title &&
      original.content === draft.content &&
      original.folder === draft.folder &&
      original.tags.join('|') === draft.tags.join('|')
    ) {
      return;
    }
    setSaveState('saving');
    const timer = window.setTimeout(() => {
      const updatedAt = new Date().toISOString();
      const nextNotes = notes.map((note) =>
        note.id === selectedId ? { ...note, ...draft, updatedAt } : note,
      );
      syncNotes(nextNotes);
      updateMutation.mutate(
        { id: selectedId, data: draft },
        {
          onSuccess: (savedNote) => {
            syncNotes(nextNotes.map((note) => (note.id === savedNote.id ? savedNote : note)));
            setSaveState('saved');
            setConnectionError(null);
          },
          onError: () => {
            setSaveState('error');
            setConnectionError('Could not save this note. Check your connection and try again.');
          },
        },
      );
    }, 420);
    return () => window.clearTimeout(timer);
  }, [draft, notes, selectedId, syncNotes, updateMutation]);

  const createNote = useCallback(() => {
    const now = new Date().toISOString();
    const newNote: Note = {
      id: makeId(),
      title: 'Untitled thought',
      content: '',
      folder: folder !== 'All notes' && folder !== 'Pinned' ? folder : 'Inbox',
      tags: [],
      pinned: false,
      createdAt: now,
      updatedAt: now,
    };
    const previousNotes = notes;
    syncNotes([newNote, ...notes]);
    setSelectedId(newNote.id);
    setFolder('All notes');
    setActiveTag(null);
    setMobileView('editor');
    createMutation.mutate(
      {
        data: {
          id: newNote.id,
          title: newNote.title,
          content: newNote.content,
          folder: newNote.folder,
          tags: newNote.tags,
          pinned: newNote.pinned,
        },
      },
      {
        onSuccess: (savedNote) => {
          syncNotes([savedNote, ...previousNotes]);
          setConnectionError(null);
        },
        onError: () => {
          syncNotes(previousNotes);
          setSelectedId(previousNotes[0]?.id ?? null);
          setConnectionError('The note could not be created. Please try again.');
        },
      },
    );
  }, [createMutation, folder, notes, syncNotes]);

  const deleteSelected = () => {
    if (!selectedNote) return;
    if (!window.confirm(`Delete “${selectedNote.title}”? This cannot be undone.`)) return;
    const remaining = notes.filter((note) => note.id !== selectedNote.id);
    syncNotes(remaining);
    setSelectedId(remaining[0]?.id ?? null);
    setMobileView('list');
    deleteMutation.mutate(
      { id: selectedNote.id },
      {
        onError: () => {
          syncNotes(notes);
          setSelectedId(selectedNote.id);
          setConnectionError('The note could not be deleted. Please try again.');
        },
      },
    );
  };

  const togglePin = (id: string) => {
    const original = notes.find((note) => note.id === id);
    if (!original) return;
    const nextNotes = notes.map((note) =>
      note.id === id
        ? { ...note, pinned: !note.pinned, updatedAt: new Date().toISOString() }
        : note,
    );
    syncNotes(nextNotes);
    updateMutation.mutate(
      { id, data: { pinned: !original.pinned } },
      {
        onSuccess: (savedNote) =>
          syncNotes(nextNotes.map((note) => (note.id === id ? savedNote : note))),
        onError: () => {
          syncNotes(notes);
          setConnectionError('The pin change could not be saved.');
        },
      },
    );
  };

  const selectNote = (id: string) => {
    setSelectedId(id);
    setMobileView('editor');
    setMobileNavOpen(false);
  };

  const clearFilters = () => {
    setQuery('');
    setFolder('All notes');
    setActiveTag(null);
  };

  const hasFilters = Boolean(query || activeTag || folder !== 'All notes');

  if (notesQuery.isLoading) {
    return (
      <div className="flex min-h-[100dvh] items-center justify-center bg-background text-sm text-muted-foreground">
        Loading your notes from the database…
      </div>
    );
  }

  if (notesQuery.isError && notes.length === 0) {
    return (
      <div className="flex min-h-[100dvh] items-center justify-center bg-background px-6 text-center">
        <div>
          <h1 className="font-display text-3xl text-foreground">The database is out of reach.</h1>
          <p className="mt-3 text-sm text-muted-foreground">Your notes are safe. Try reconnecting to load them.</p>
          <button type="button" onClick={() => notesQuery.refetch()} className="mt-6 rounded-lg bg-[hsl(var(--primary))] px-4 py-2.5 text-sm font-bold text-[hsl(var(--primary-foreground))]">
            Try again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[100dvh] bg-background text-foreground">
      <div className="flex min-h-[100dvh]">
        <aside
          className={`fixed inset-y-0 left-0 z-40 w-[276px] shrink-0 bg-[hsl(var(--sidebar))] text-[hsl(var(--sidebar-foreground))] shadow-[8px_0_32px_hsl(191_24%_22%_/.08)] transition-transform duration-300 md:relative md:translate-x-0 ${
            mobileNavOpen ? 'translate-x-0' : '-translate-x-full'
          }`}
        >
          <div className="flex h-full flex-col px-5 py-6">
            <div className="flex items-center justify-between px-2">
              <div className="flex items-center gap-3">
                <div className="relative flex h-9 w-9 items-center justify-center rounded-[11px] bg-[hsl(var(--accent))] text-[hsl(var(--sidebar))]">
                  <BookOpen size={18} strokeWidth={2.2} />
                  <span className="absolute -right-1 -top-1 h-2.5 w-2.5 rounded-full border-2 border-[hsl(var(--sidebar))] bg-[hsl(35_73%_66%)]" />
                </div>
                <div>
                  <p className="font-display text-[23px] leading-none tracking-[-.02em]">Morrow</p>
                  <p className="mt-1 font-mono-app text-[9px] uppercase tracking-[.2em] text-[hsl(var(--sidebar-foreground)/.52)]">a place for thoughts</p>
                </div>
              </div>
              <IconButton label="Close navigation" onClick={() => setMobileNavOpen(false)} className="md:hidden">
                <X size={17} />
              </IconButton>
            </div>

            <button
              type="button"
              onClick={createNote}
              data-testid="button-new-note"
              className="mt-10 flex w-full items-center justify-between rounded-xl bg-[hsl(var(--accent))] px-4 py-3 text-left text-[hsl(var(--sidebar))] shadow-[0_7px_18px_hsl(174_39%_15%_/.18)] transition-all hover:-translate-y-0.5 hover:shadow-[0_10px_22px_hsl(174_39%_15%_/.24)] active:translate-y-0"
            >
              <span className="flex items-center gap-2.5 text-sm font-bold"><Plus size={17} /> New note</span>
              <span className="font-mono-app text-[10px] opacity-60">N</span>
            </button>

            <nav className="mt-8" aria-label="Notes views">
              <p className="mb-3 px-3 font-mono-app text-[10px] uppercase tracking-[.17em] text-[hsl(var(--sidebar-foreground)/.43)]">Library</p>
              <SidebarItem label="All notes" icon={<FileText size={17} />} count={notes.length} active={folder === 'All notes'} onClick={() => { setFolder('All notes'); setActiveTag(null); setMobileNavOpen(false); }} />
              <SidebarItem label="Pinned" icon={<Pin size={16} />} count={notes.filter((note) => note.pinned).length} active={folder === 'Pinned'} onClick={() => { setFolder('Pinned'); setActiveTag(null); setMobileNavOpen(false); }} />
              <SidebarItem label="Archive" icon={<Archive size={17} />} count={0} active={false} onClick={() => { setFolder('Archive'); setActiveTag(null); setMobileNavOpen(false); }} />
            </nav>

            <div className="mt-8">
              <div className="mb-3 flex items-center justify-between px-3">
                <p className="font-mono-app text-[10px] uppercase tracking-[.17em] text-[hsl(var(--sidebar-foreground)/.43)]">Folders</p>
                <button type="button" aria-label="Add folder" data-testid="button-add-folder" onClick={() => window.alert('Folders are created from the note editor.')} className="text-[hsl(var(--sidebar-foreground)/.5)] transition-colors hover:text-[hsl(var(--accent))]"><Plus size={14} /></button>
              </div>
              {folders.map((item) => (
                <SidebarItem key={item} label={item} icon={<Folder size={16} />} count={notes.filter((note) => note.folder === item).length} active={folder === item} onClick={() => { setFolder(item); setActiveTag(null); setMobileNavOpen(false); }} />
              ))}
            </div>

            <div className="mt-8">
              <p className="mb-3 px-3 font-mono-app text-[10px] uppercase tracking-[.17em] text-[hsl(var(--sidebar-foreground)/.43)]">Tags</p>
              <div className="flex flex-wrap gap-2 px-2">
                {tags.map((tag) => (
                  <button
                    type="button"
                    key={tag}
                    onClick={() => { setActiveTag(activeTag === tag ? null : tag); setFolder('All notes'); setMobileNavOpen(false); }}
                    data-testid={`button-tag-${tag}`}
                    className={`rounded-md border px-2.5 py-1.5 font-mono-app text-[10px] transition-colors ${activeTag === tag ? 'border-[hsl(var(--accent)/.65)] bg-[hsl(var(--accent)/.16)] text-[hsl(var(--accent))]' : 'border-[hsl(var(--sidebar-foreground)/.12)] text-[hsl(var(--sidebar-foreground)/.55)] hover:border-[hsl(var(--accent)/.5)] hover:text-[hsl(var(--sidebar-foreground))]'}`}
                  >
                    #{tag}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-auto border-t border-[hsl(var(--sidebar-foreground)/.11)] pt-4">
              <button type="button" data-testid="button-settings" onClick={() => window.alert('Morrow saves notes in this project’s built-in PostgreSQL database.')} className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-[hsl(var(--sidebar-foreground)/.58)] transition-colors hover:bg-[hsl(var(--sidebar-accent))] hover:text-[hsl(var(--sidebar-foreground))]"><Settings2 size={16} /> Database</button>
              <p className="mt-4 px-3 font-mono-app text-[9px] leading-relaxed text-[hsl(var(--sidebar-foreground)/.34)]">Saved to the built-in database.<br />Available on Mac and iPhone.</p>
            </div>
          </div>
        </aside>

        {mobileNavOpen && <button type="button" aria-label="Close navigation overlay" data-testid="button-close-navigation-overlay" onClick={() => setMobileNavOpen(false)} className="fixed inset-0 z-30 bg-[hsl(191_34%_12%_/.42)] md:hidden" />}

        <main className="min-w-0 flex-1">
          <header className="flex h-[76px] items-center justify-between border-b border-border/70 px-5 sm:px-8 lg:px-10">
            <div className="flex min-w-0 items-center gap-3">
              <IconButton label="Open navigation" onClick={() => setMobileNavOpen(true)} className="md:hidden">
                <Menu size={19} />
              </IconButton>
              <div className="relative w-full max-w-[370px]">
                <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  ref={searchRef}
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  type="search"
                  placeholder="Search your thoughts"
                  data-testid="input-search-notes"
                  className="h-10 w-full rounded-xl border border-border/80 bg-card/55 pl-10 pr-12 text-sm outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-[hsl(var(--accent)/.8)] focus:bg-card"
                />
                <span className="pointer-events-none absolute right-3 top-1/2 hidden -translate-y-1/2 rounded border border-border bg-muted/70 px-1.5 py-0.5 font-mono-app text-[9px] text-muted-foreground sm:block">⌘ K</span>
              </div>
            </div>
            <div className="hidden items-center gap-3 text-xs text-muted-foreground sm:flex">
              <span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--accent))]" />
              <span data-testid="status-sync">{connectionError ?? 'Synced with database'}</span>
            </div>
          </header>

          <div className="grid min-h-[calc(100dvh-76px)] grid-cols-1 md:grid-cols-[minmax(260px,330px)_minmax(0,1fr)]">
            <section className={`${mobileView === 'editor' ? 'hidden md:block' : 'block'} border-r border-border/70`}>
              <div className="flex items-end justify-between px-5 pb-5 pt-8 sm:px-7">
                <div>
                  <p className="font-mono-app text-[10px] uppercase tracking-[.18em] text-muted-foreground">{folder === 'All notes' ? 'Your notebook' : folder}</p>
                  <h1 className="mt-1 font-display text-[34px] leading-none tracking-[-.03em]">{folder === 'All notes' ? 'All notes' : folder}</h1>
                </div>
                <span className="mb-1 font-mono-app text-[11px] text-muted-foreground" data-testid="text-note-count">{filteredNotes.length.toString().padStart(2, '0')}</span>
              </div>
              <div className="px-3 pb-4 sm:px-4">
                {hasFilters && (
                  <div className="mb-3 flex items-center justify-between rounded-lg bg-[hsl(var(--accent)/.1)] px-3 py-2 text-xs text-[hsl(var(--primary))]">
                    <span>{query ? `Showing matches for “${query}”` : activeTag ? `Tagged #${activeTag}` : `Inside ${folder}`}</span>
                    <button type="button" data-testid="button-clear-filters" onClick={clearFilters} className="font-semibold hover:underline">Clear</button>
                  </div>
                )}
                <div className="space-y-1.5">
                  {filteredNotes.map((note, index) => (
                    <NoteListItem key={note.id} note={note} active={note.id === selectedId} index={index} onClick={() => selectNote(note.id)} onPin={() => togglePin(note.id)} />
                  ))}
                </div>
                {filteredNotes.length === 0 && (
                  <EmptyList hasFilters={hasFilters} onClear={clearFilters} onCreate={createNote} />
                )}
              </div>
              <div className="note-grid mx-5 mt-4 hidden h-24 rounded-xl opacity-35 sm:block" />
            </section>

            <section className={`${mobileView === 'list' ? 'hidden md:flex' : 'flex'} min-w-0 flex-col bg-[hsl(var(--card)/.38)]`}>
              {selectedNote ? (
                <Editor
                  note={selectedNote}
                  draft={draft}
                  setDraft={setDraft}
                  saveState={saveState}
                  onBack={() => setMobileView('list')}
                  onPin={() => togglePin(selectedNote.id)}
                  onDelete={deleteSelected}
                />
              ) : (
                <EmptyEditor onCreate={createNote} />
              )}
            </section>
          </div>
        </main>
      </div>
    </div>
  );
}

function SidebarItem({ label, icon, count, active, onClick }: { label: string; icon: ReactNode; count: number; active: boolean; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} data-testid={`button-folder-${label.toLowerCase().replace(/\s+/g, '-')}`} className={`group flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-sm transition-colors ${active ? 'bg-[hsl(var(--sidebar-accent))] text-[hsl(var(--sidebar-foreground))]' : 'text-[hsl(var(--sidebar-foreground)/.62)] hover:bg-[hsl(var(--sidebar-accent)/.65)] hover:text-[hsl(var(--sidebar-foreground))]'}`}>
      <span className="flex items-center gap-3">{icon}<span>{label}</span></span>
      <span className={`font-mono-app text-[10px] ${active ? 'text-[hsl(var(--accent))]' : 'text-[hsl(var(--sidebar-foreground)/.3)]'}`}>{count}</span>
    </button>
  );
}

function NoteListItem({ note, active, index, onClick, onPin }: { note: Note; active: boolean; index: number; onClick: () => void; onPin: () => void }) {
  return (
    <div className={`group relative animate-rise-in rounded-xl border transition-all duration-200 ${active ? 'border-[hsl(var(--accent)/.5)] bg-card shadow-[var(--shadow-sm)]' : 'border-transparent hover:border-border hover:bg-card/65'}`} style={{ animationDelay: `${Math.min(index, 6) * 35}ms` }}>
      <button type="button" onClick={onClick} data-testid={`button-open-note-${note.id}`} className="w-full px-4 pb-3.5 pt-3.5 text-left">
        <div className="flex items-start justify-between gap-3">
          <h2 className={`min-w-0 truncate text-[13px] font-bold ${active ? 'text-[hsl(var(--primary))]' : 'text-foreground/85'}`}>{note.title || 'Untitled thought'}</h2>
          {note.pinned && <Pin size={13} className="mt-0.5 shrink-0 fill-[hsl(var(--accent))] text-[hsl(var(--accent))]" />}
        </div>
        <p className="mt-1.5 line-clamp-2 text-[11px] leading-[1.55] text-muted-foreground">{getPreview(note.content)}</p>
        <div className="mt-3 flex items-center justify-between gap-2">
          <span className="font-mono-app text-[9px] uppercase tracking-[.08em] text-muted-foreground/75">{note.folder}</span>
          <span className="font-mono-app text-[9px] text-muted-foreground/65">{formatDate(note.updatedAt)}</span>
        </div>
      </button>
      <button type="button" aria-label={note.pinned ? 'Unpin note' : 'Pin note'} title={note.pinned ? 'Unpin note' : 'Pin note'} data-testid={`button-pin-note-${note.id}`} onClick={onPin} className="absolute bottom-2.5 right-3 hidden h-6 w-6 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-[hsl(var(--primary))] group-hover:flex">
        <Pin size={12} className={note.pinned ? 'fill-[hsl(var(--accent))] text-[hsl(var(--accent))]' : ''} />
      </button>
    </div>
  );
}

function EmptyList({ hasFilters, onClear, onCreate }: { hasFilters: boolean; onClear: () => void; onCreate: () => void }) {
  return (
    <div className="animate-fade-in px-5 py-16 text-center">
      <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[hsl(var(--accent)/.13)] text-[hsl(var(--primary))]"><Search size={20} /></div>
      <h2 className="mt-5 font-display text-[25px]">Nothing here yet</h2>
      <p className="mx-auto mt-2 max-w-[220px] text-xs leading-relaxed text-muted-foreground">{hasFilters ? 'Try another search or gently clear the filters.' : 'This corner is ready for the next thing you notice.'}</p>
      <button type="button" data-testid={hasFilters ? 'button-empty-clear' : 'button-empty-create'} onClick={hasFilters ? onClear : onCreate} className="mt-5 text-xs font-bold text-[hsl(var(--primary))] underline decoration-[hsl(var(--accent)/.5)] underline-offset-4">{hasFilters ? 'Clear filters' : 'Write a note'}</button>
    </div>
  );
}

function EmptyEditor({ onCreate }: { onCreate: () => void }) {
  return (
    <div className="flex min-h-full flex-1 items-center justify-center p-8">
      <div className="max-w-sm text-center">
        <div className="mx-auto flex h-16 w-16 rotate-[-4deg] items-center justify-center rounded-[20px] border border-[hsl(var(--accent)/.3)] bg-[hsl(var(--accent)/.1)] text-[hsl(var(--primary))]"><Lightbulb size={26} strokeWidth={1.6} /></div>
        <p className="mt-7 font-mono-app text-[10px] uppercase tracking-[.2em] text-muted-foreground">A clear page</p>
        <h2 className="mt-2 font-display text-4xl">Make room for a thought.</h2>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">The best notes often start before they are fully formed.</p>
        <button type="button" onClick={onCreate} data-testid="button-empty-editor-new-note" className="mt-7 inline-flex items-center gap-2 rounded-lg bg-[hsl(var(--primary))] px-4 py-2.5 text-sm font-bold text-[hsl(var(--primary-foreground))] transition-transform hover:-translate-y-0.5"><Plus size={16} /> New note</button>
      </div>
    </div>
  );
}

function Editor({
  note,
  draft,
  setDraft,
  saveState,
  onBack,
  onPin,
  onDelete,
}: {
  note: Note;
  draft: Pick<Note, 'title' | 'content' | 'folder' | 'tags'>;
  setDraft: Dispatch<SetStateAction<Pick<Note, 'title' | 'content' | 'folder' | 'tags'>>>;
  saveState: 'saved' | 'saving' | 'error';
  onBack: () => void;
  onPin: () => void;
  onDelete: () => void;
}) {
  const [tagInput, setTagInput] = useState('');
  const [detailsOpen, setDetailsOpen] = useState(false);
  const updateDraft = <K extends keyof typeof draft>(key: K, value: (typeof draft)[K]) => setDraft((current) => ({ ...current, [key]: value }));
  const addTag = () => {
    const clean = tagInput.trim().toLowerCase().replace(/^#/, '');
    if (clean && !draft.tags.includes(clean)) updateDraft('tags', [...draft.tags, clean]);
    setTagInput('');
  };

  return (
    <div className="flex min-h-full flex-1 flex-col animate-fade-in">
      <div className="flex items-center justify-between border-b border-border/65 px-5 py-4 sm:px-10">
        <button type="button" onClick={onBack} data-testid="button-back-to-notes" className="inline-flex items-center gap-2 text-xs font-bold text-muted-foreground transition-colors hover:text-foreground md:hidden"><ArrowLeft size={16} /> All notes</button>
        <div className="hidden items-center gap-2 text-[11px] text-muted-foreground md:flex"><span className={`h-1.5 w-1.5 rounded-full ${saveState === 'saving' ? 'bg-[hsl(35_73%_66%)]' : saveState === 'error' ? 'bg-[hsl(var(--destructive))]' : 'bg-[hsl(var(--accent))]'}`} /><span data-testid="status-autosave">{saveState === 'saving' ? 'Saving to database…' : saveState === 'error' ? 'Save failed' : 'Saved to database'}</span></div>
        <div className="ml-auto flex items-center gap-1 text-muted-foreground">
          <IconButton label={note.pinned ? 'Unpin note' : 'Pin note'} active={note.pinned} onClick={onPin}><Pin size={17} className={note.pinned ? 'fill-current' : ''} /></IconButton>
          <IconButton label="Delete note" onClick={onDelete} className="hover:text-[hsl(var(--destructive))]"><Trash2 size={17} /></IconButton>
          <IconButton label="More options" onClick={() => setDetailsOpen((open) => !open)}><MoreHorizontal size={18} /></IconButton>
        </div>
      </div>

      <div className="mx-auto flex w-full max-w-[790px] flex-1 flex-col px-6 pb-20 pt-10 sm:px-12 sm:pt-16 lg:px-20">
        <div className="mb-6 flex items-center gap-2 text-[10px] uppercase tracking-[.16em] text-muted-foreground">
          <span className="flex items-center gap-1.5"><Folder size={12} /> {draft.folder}</span>
          <span className="text-border">/</span>
          <span>{formatDate(note.createdAt)}</span>
        </div>
        <input
          value={draft.title}
          onChange={(event) => updateDraft('title', event.target.value)}
          data-testid={`input-note-title-${note.id}`}
          aria-label="Note title"
          className="w-full border-0 bg-transparent font-display text-[clamp(2.7rem,5vw,4.6rem)] leading-[.98] tracking-[-.035em] text-[hsl(var(--primary))] outline-none placeholder:text-[hsl(var(--primary)/.32)]"
          placeholder="Untitled thought"
        />
        <div className="mt-8 h-px w-12 bg-[hsl(var(--accent))]" />
        <textarea
          value={draft.content}
          onChange={(event) => updateDraft('content', event.target.value)}
          data-testid={`textarea-note-content-${note.id}`}
          aria-label="Note content"
          placeholder="Begin anywhere…"
          className="mt-8 min-h-[390px] w-full resize-none border-0 bg-transparent text-[15px] leading-[1.9] text-foreground/80 outline-none placeholder:text-muted-foreground/60"
        />

        <div className="mt-auto border-t border-border/65 pt-4">
          <button type="button" onClick={() => setDetailsOpen((open) => !open)} data-testid="button-note-details" className="flex w-full items-center justify-between py-1 text-left text-xs text-muted-foreground hover:text-foreground">
            <span className="flex items-center gap-2"><Hash size={14} /> {draft.tags.length ? draft.tags.map((tag) => `#${tag}`).join('  ') : 'Add a tag to find this later'}</span>
            <ChevronDown size={15} className={`transition-transform ${detailsOpen ? 'rotate-180' : ''}`} />
          </button>
          {detailsOpen && (
            <div className="mt-4 grid gap-4 rounded-xl border border-border/70 bg-background/45 p-4 sm:grid-cols-2 animate-fade-in">
              <label className="text-xs font-semibold text-muted-foreground">Folder
                <div className="relative mt-2">
                  <select value={draft.folder} onChange={(event) => updateDraft('folder', event.target.value)} data-testid="select-note-folder" className="h-10 w-full appearance-none rounded-lg border border-input bg-card px-3 pr-9 text-sm text-foreground outline-none focus:border-[hsl(var(--accent))]">
                    {DEFAULT_FOLDERS.map((item) => <option key={item} value={item}>{item}</option>)}
                    {!DEFAULT_FOLDERS.includes(draft.folder) && <option value={draft.folder}>{draft.folder}</option>}
                  </select>
                  <ChevronDown size={14} className="pointer-events-none absolute right-3 top-3 text-muted-foreground" />
                </div>
              </label>
              <label className="text-xs font-semibold text-muted-foreground">Tags
                <div className="mt-2 flex min-h-10 flex-wrap items-center gap-1.5 rounded-lg border border-input bg-card px-2">
                  {draft.tags.map((tag) => <button type="button" key={tag} onClick={() => updateDraft('tags', draft.tags.filter((item) => item !== tag))} data-testid={`button-remove-tag-${tag}`} className="rounded bg-[hsl(var(--accent)/.16)] px-2 py-1 font-mono-app text-[10px] text-[hsl(var(--primary))]">#{tag} <X size={10} className="ml-1 inline" /></button>)}
                  <input value={tagInput} onChange={(event) => setTagInput(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') { event.preventDefault(); addTag(); } }} onBlur={addTag} placeholder="Add tag…" data-testid="input-note-tag" className="min-w-[76px] flex-1 bg-transparent px-1 py-1.5 text-xs outline-none" />
                </div>
              </label>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <NotesApp />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;