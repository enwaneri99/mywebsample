import { useVideoPlayer } from '@/lib/video';
import { AnimatePresence, motion } from 'framer-motion';

import { Scene1 } from './video_scenes/Scene1';
import { Scene2 } from './video_scenes/Scene2';
import { Scene3 } from './video_scenes/Scene3';
import { Scene4 } from './video_scenes/Scene4';
import { Scene5 } from './video_scenes/Scene5';
import { Scene6 } from './video_scenes/Scene6';

const SCENE_DURATIONS = {
  opening: 4200,
  capture: 5200,
  shape: 5200,
  search: 4700,
  surfaces: 4700,
  close: 5000,
};

export default function VideoTemplate() {
  const { currentScene } = useVideoPlayer({
    durations: SCENE_DURATIONS,
  });

  return (
    <div className="video-root">
      <div className="video-stage">
        <motion.div className="pointer-events-none absolute inset-0 z-0" animate={{ background: currentScene === 0 ? 'radial-gradient(circle at 68% 22%, #2b7776 0%, #173b3f 45%, #173b3f 100%)' : currentScene === 1 ? 'radial-gradient(circle at 30% 85%, #d9e8de 0%, #f6f0e7 42%, #f6f0e7 100%)' : currentScene === 2 ? 'radial-gradient(circle at 80% 15%, #2b7776 0%, #215f63 42%, #215f63 100%)' : currentScene === 3 ? 'radial-gradient(circle at 16% 72%, #f6d18b 0%, #fffaf1 38%, #fffaf1 100%)' : currentScene === 4 ? 'radial-gradient(circle at 78% 72%, #d95e4b 0%, #f07b5f 45%, #f07b5f 100%)' : 'radial-gradient(circle at 75% 28%, #215f63 0%, #173b3f 48%, #173b3f 100%)' }} transition={{ duration: 1.25, ease: [0.16, 1, 0.3, 1] }} />
        <motion.div
          className="pointer-events-none absolute left-[52vw] top-[35vw] z-[1] h-[16vw] w-[16vw] rounded-full border-[.1vw] border-[#f6d18b]/30"
          animate={{
            x: currentScene < 2 ? '18vw' : currentScene < 4 ? '-20vw' : '10vw',
            y: currentScene % 2 ? '-18vw' : '9vw',
            rotate: currentScene * 42,
            scale: currentScene === 0 ? 1.35 : .78,
          }}
          transition={{ duration: 1.45, ease: [0.16, 1, 0.3, 1] }}
        />
        <motion.div
          className="pointer-events-none absolute left-[12vw] top-[8vw] z-[1] h-[.1vw] w-[12vw] origin-left bg-[#f07b5f]"
          animate={{ scaleX: currentScene === 0 ? 1 : currentScene === 5 ? .45 : .75, rotate: currentScene % 2 ? 7 : -4, x: currentScene * 2.4 + 'vw', opacity: currentScene === 4 ? .7 : 1 }}
          transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
        />
        <AnimatePresence mode="sync" initial={false}>
          {currentScene === 0 && <Scene1 />}
          {currentScene === 1 && <Scene2 />}
          {currentScene === 2 && <Scene3 />}
          {currentScene === 3 && <Scene4 />}
          {currentScene === 4 && <Scene5 />}
          {currentScene === 5 && <Scene6 />}
        </AnimatePresence>
        <div className="grain" />
        <div className="font-mono-video absolute bottom-[1.7vw] right-[2.4vw] z-40 text-[.5vw] uppercase tracking-[.18em] text-[#fffaf1]/45">MORROW / NOTES</div>
      </div>
    </div>
  );
}
