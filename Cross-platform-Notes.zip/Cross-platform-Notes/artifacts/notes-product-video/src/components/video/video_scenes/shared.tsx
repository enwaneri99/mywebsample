import {
  Archive,
  BookOpen,
  ChevronDown,
  FileText,
  Folder,
  Hash,
  MoreHorizontal,
  Pin,
  Plus,
  Search,
  Trash2,
} from 'lucide-react';
import { motion } from 'framer-motion';
import type { ReactNode } from 'react';

export const ease = [0.16, 1, 0.3, 1] as const;

export function SceneTag({ children }: { children: ReactNode }) {
  return (
    <div className="font-mono-video flex items-center gap-[.7vw] text-[.72vw] uppercase tracking-[.18em] text-[#f6d18b]">
      <span className="h-[.42vw] w-[.42vw] rounded-full bg-[#f6d18b]" />
      {children}
    </div>
  );
}

export function SceneTitle({
  eyebrow,
  children,
  light = false,
  className = '',
}: {
  eyebrow: string;
  children: ReactNode;
  light?: boolean;
  className?: string;
}) {
  return (
    <div className={`relative z-10 ${className}`}>
      <SceneTag>{eyebrow}</SceneTag>
      <h2 className={`font-display mt-[1.3vw] max-w-[39vw] text-[6.1vw] leading-[.86] tracking-[-.045em] ${light ? 'text-[#fffaf1]' : 'text-[#173b3f]'}`}>
        {children}
      </h2>
    </div>
  );
}

export function AppLogo({ dark = false, compact = false }: { dark?: boolean; compact?: boolean }) {
  return (
    <div className={`flex items-center gap-[.7vw] ${dark ? 'text-[#fffaf1]' : 'text-[#173b3f]'}`}>
      <div className={`relative flex items-center justify-center rounded-[.65vw] bg-[#f07b5f] ${compact ? 'h-[1.7vw] w-[1.7vw]' : 'h-[2.2vw] w-[2.2vw]'}`}>
        <BookOpen size={compact ? 11 : 14} strokeWidth={2.4} className="text-[#fffaf1]" />
        <span className="absolute -right-[.18vw] -top-[.18vw] h-[.48vw] w-[.48vw] rounded-full border-[.12vw] border-[#173b3f] bg-[#f6d18b]" />
      </div>
      {!compact && (
        <div>
          <p className="font-display text-[1.6vw] leading-none">Morrow</p>
          <p className="font-mono-video mt-[.25vw] text-[.48vw] uppercase tracking-[.16em] opacity-50">a place for thoughts</p>
        </div>
      )}
    </div>
  );
}

export function Cursor({ x = 0, y = 0, delay = 0 }: { x?: number; y?: number; delay?: number }) {
  return (
    <motion.div
      className="pointer-events-none absolute z-30"
      animate={{ x: `${x}vw`, y: `${y}vw`, opacity: [0, 1, 1, 0] }}
      transition={{ delay, duration: 2.4, times: [0, .12, .75, 1], ease }}
      style={{ left: '50%', top: '50%' }}
    >
      <div className="h-[1.25vw] w-[.9vw] rotate-[-16deg] border-[.14vw] border-[#fffaf1] bg-[#173b3f] shadow-[0_.2vw_.45vw_rgba(0,0,0,.25)]" style={{ clipPath: 'polygon(0 0, 100% 78%, 61% 74%, 48% 100%)' }} />
    </motion.div>
  );
}

export function WebSidebar({ active = 'All notes', compact = false }: { active?: string; compact?: boolean }) {
  const item = (label: string, icon: ReactNode, count: string) => (
    <div className={`flex items-center justify-between rounded-[.5vw] px-[.7vw] py-[.55vw] ${active === label ? 'bg-[#2b7776] text-[#fffaf1]' : 'text-[#e7f0e7]/60'}`}>
      <span className="flex items-center gap-[.65vw]">{icon}<span>{label}</span></span>
      <span className="font-mono-video text-[.58vw] opacity-45">{count}</span>
    </div>
  );
  return (
    <aside className={`flex h-full flex-col bg-[#215f63] text-[#fffaf1] ${compact ? 'w-[12vw] px-[.7vw] py-[.9vw]' : 'w-[14vw] px-[1vw] py-[1.15vw]'}`}>
      <AppLogo dark compact={compact} />
      {!compact && (
        <>
          <div className="mt-[2vw] flex items-center justify-between rounded-[.62vw] bg-[#f07b5f] px-[.8vw] py-[.72vw] text-[#fffaf1]">
            <span className="flex items-center gap-[.5vw] text-[.72vw] font-bold"><Plus size={12} /> New note</span>
            <span className="font-mono-video text-[.5vw] opacity-60">N</span>
          </div>
          <p className="font-mono-video mb-[.45vw] mt-[1.8vw] px-[.65vw] text-[.5vw] uppercase tracking-[.15em] opacity-45">Library</p>
          {item('All notes', <FileText size={12} />, '03')}
          {item('Pinned', <Pin size={12} />, '01')}
          {item('Archive', <Archive size={12} />, '00')}
          <p className="font-mono-video mb-[.45vw] mt-[1.5vw] px-[.65vw] text-[.5vw] uppercase tracking-[.15em] opacity-45">Folders</p>
          {['Inbox', 'Ideas', 'Journal', 'Work'].map((label, i) => item(label, <Folder size={12} />, String(i === 0 ? 0 : 1).padStart(2, '0')))}
          <p className="font-mono-video mb-[.45vw] mt-[1.5vw] px-[.65vw] text-[.5vw] uppercase tracking-[.15em] opacity-45">Tags</p>
          <div className="flex flex-wrap gap-[.35vw] px-[.45vw]">
            {['reading', 'project', 'personal'].map((tag) => <span key={tag} className="rounded-[.3vw] border border-[#fffaf1]/15 px-[.42vw] py-[.3vw] font-mono-video text-[.48vw] text-[#fffaf1]/65">#{tag}</span>)}
          </div>
        </>
      )}
      {compact && <div className="mt-[1vw] flex flex-col gap-[.45vw]">{[<FileText key="f" size={12} />, <Pin key="p" size={12} />, <Folder key="d" size={12} />, <Hash key="h" size={12} />].map((icon, i) => <div key={i} className="flex h-[1.8vw] items-center justify-center rounded-[.4vw] text-[#fffaf1]/50">{icon}</div>)}</div>}
      <div className="mt-auto border-t border-[#fffaf1]/12 pt-[.7vw] font-mono-video text-[.45vw] leading-relaxed text-[#fffaf1]/35">{compact ? 'local' : <>Your notes live quietly<br />on this device.</>}</div>
    </aside>
  );
}

export function WebWindow({
  children,
  className = '',
  sidebar = true,
  title = 'Morrow — Notes',
}: {
  children: ReactNode;
  className?: string;
  sidebar?: boolean;
  title?: string;
}) {
  return (
    <div className={`overflow-hidden rounded-[1vw] border-[.12vw] border-[#173b3f]/15 bg-[#f8f4ec] app-shadow ${className}`}>
      <div className="flex h-[2.25vw] items-center gap-[.45vw] border-b border-[#173b3f]/10 bg-[#ece7dd] px-[.8vw]">
        <span className="h-[.5vw] w-[.5vw] rounded-full bg-[#ef8065]" /><span className="h-[.5vw] w-[.5vw] rounded-full bg-[#e7bb6d]" /><span className="h-[.5vw] w-[.5vw] rounded-full bg-[#76a89e]" />
        <span className="font-mono-video ml-[1vw] text-[.55vw] tracking-[.02em] text-[#173b3f]/45">{title}</span>
      </div>
      <div className="flex h-[calc(100%-2.25vw)] min-h-0">
        {sidebar && <WebSidebar />}
        {children}
      </div>
    </div>
  );
}

export function WebNoteList({ search = '', active = 'A slower way to begin', showDetails = true }: { search?: string; active?: string; showDetails?: boolean }) {
  const notes = [
    ['A slower way to begin', 'Before reaching for a screen, leave one small margin for noticing.', 'Journal', 'now', true],
    ['Books to return to', 'The best reading list is not a queue. It is a little map.', 'Ideas', 'Mar 17', false],
    ['Sunday project notes', 'Make the first version small enough to finish in one sitting.', 'Work', 'Mar 15', false],
  ] as const;
  const shown = search ? notes.filter(([title, body]) => `${title} ${body}`.toLowerCase().includes(search.toLowerCase())) : notes;
  return (
    <div className="min-w-0 flex-1 bg-[#faf7f1]">
      <div className="flex items-end justify-between px-[1.15vw] pb-[1vw] pt-[1.3vw]">
        <div><p className="font-mono-video text-[.52vw] uppercase tracking-[.15em] text-[#66827f]">{search ? 'Search results' : 'Your notebook'}</p><h3 className="font-display mt-[.28vw] text-[2.2vw] leading-none text-[#173b3f]">{search ? 'Matches' : 'All notes'}</h3></div>
        <span className="font-mono-video text-[.6vw] text-[#66827f]">{String(shown.length).padStart(2, '0')}</span>
      </div>
      {search && <div className="mx-[.85vw] mb-[.55vw] rounded-[.45vw] bg-[#d9e8de] px-[.65vw] py-[.55vw] font-mono-video text-[.52vw] text-[#24545a]">Showing matches for “{search}”</div>}
      <div className="space-y-[.4vw] px-[.55vw]">
        {shown.map(([title, body, folder, date, pinned], i) => (
          <motion.div key={title} animate={{ x: active === title ? 0 : i * .08, opacity: 1 }} transition={{ duration: .5, ease }} className={`relative rounded-[.65vw] border px-[.8vw] py-[.75vw] ${active === title ? 'border-[#8dbfb7] bg-[#fffdf9] shadow-[0_.35vw_.8vw_rgba(23,59,63,.06)]' : 'border-transparent bg-[#f7f2ea]'}`}>
            <div className="flex items-start justify-between gap-[.5vw]"><p className="truncate text-[.72vw] font-bold text-[#173b3f]">{title}</p>{pinned && <Pin size={10} className="shrink-0 fill-[#f07b5f] text-[#f07b5f]" />}</div>
            {showDetails && <p className="mt-[.35vw] line-clamp-2 text-[.58vw] leading-[1.5] text-[#66827f]">{body}</p>}
            <div className="mt-[.65vw] flex justify-between font-mono-video text-[.48vw] uppercase tracking-[.06em] text-[#66827f]/75"><span>{folder}</span><span>{date}</span></div>
          </motion.div>
        ))}
        {shown.length === 0 && <div className="px-[1vw] py-[2vw] text-center text-[.65vw] text-[#66827f]">Nothing matches this search.</div>}
      </div>
    </div>
  );
}

export function WebEditor({ typing = false, details = false, saved = true }: { typing?: boolean; details?: boolean; saved?: boolean }) {
  return (
    <div className="min-w-0 flex-1 bg-[#faf7f1]">
      <div className="flex h-[3vw] items-center justify-between border-b border-[#173b3f]/10 px-[1.3vw]">
        <div className="flex items-center gap-[.4vw] font-mono-video text-[.52vw] text-[#66827f]"><span className={`h-[.35vw] w-[.35vw] rounded-full ${saved ? 'bg-[#8dbfb7]' : 'bg-[#f6d18b]'}`} />{saved ? 'Saved just now' : 'Saving quietly'}</div>
        <div className="flex items-center gap-[.8vw] text-[#66827f]"><Pin size={12} className="fill-[#f07b5f] text-[#f07b5f]" /><Trash2 size={11} /><MoreHorizontal size={13} /></div>
      </div>
      <div className="px-[1.75vw] pb-[1.5vw] pt-[1.65vw]">
        <div className="mb-[1vw] flex items-center gap-[.45vw] font-mono-video text-[.5vw] uppercase tracking-[.12em] text-[#66827f]"><Folder size={10} /> Journal <span className="text-[#173b3f]/20">/</span> Aug 26</div>
        <motion.div animate={{ y: typing ? [-2, 0] : 0 }} transition={{ duration: .8, ease }} className="font-display text-[3.1vw] leading-[.9] tracking-[-.04em] text-[#173b3f]">A slower way<br />to begin</motion.div>
        <div className="mt-[1.2vw] h-[.08vw] w-[2.4vw] bg-[#f07b5f]" />
        <div className="mt-[1.15vw] max-w-[28vw] text-[.68vw] leading-[1.72] text-[#173b3f]/70">
          Before reaching for a screen, leave one small margin for noticing.<br /><br />
          <span className={typing ? 'text-[#173b3f]' : ''}>The question is not “what can I fit in?” but “what deserves my first attention?”</span>
          {typing && <motion.span animate={{ opacity: [1, 0, 1] }} transition={{ repeat: Infinity, duration: .8 }} className="ml-[.12vw] inline-block h-[.85vw] w-[.07vw] bg-[#f07b5f] align-middle" />}
        </div>
        <div className="mt-[1.3vw] border-t border-[#173b3f]/10 pt-[.7vw]">
          <div className="flex items-center gap-[.45vw] font-mono-video text-[.5vw] text-[#66827f]"><Hash size={10} /><span className="text-[#24545a]">#personal</span><span className="text-[#24545a]">#reading</span><ChevronDown size={10} className="ml-auto" /></div>
          {details && <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className="mt-[.75vw] grid grid-cols-2 gap-[.6vw] rounded-[.55vw] border border-[#173b3f]/10 bg-[#f6f0e7] p-[.6vw] text-[.52vw] text-[#66827f]"><div><b className="block text-[#173b3f]">Folder</b><span className="mt-[.3vw] inline-block rounded-[.35vw] bg-[#d9e8de] px-[.45vw] py-[.3vw] text-[#24545a]">Journal</span></div><div><b className="block text-[#173b3f]">Tags</b><span className="mt-[.3vw] inline-block text-[#24545a]">personal, reading</span></div></motion.div>}
        </div>
      </div>
    </div>
  );
}

export function PhoneFrame({ children, className = '', label }: { children: ReactNode; className?: string; label?: string }) {
  return (
    <div className={`relative rounded-[2.2vw] border-[.2vw] border-[#102f33] bg-[#102f33] p-[.48vw] phone-shadow ${className}`}>
      <div className="absolute left-1/2 top-[.45vw] z-10 h-[.55vw] w-[4.2vw] -translate-x-1/2 rounded-full bg-[#0b2326]" />
      <div className="relative h-full overflow-hidden rounded-[1.8vw] bg-[#f7f2ea]">{children}</div>
      {label && <div className="absolute -bottom-[2.1vw] left-1/2 -translate-x-1/2 whitespace-nowrap font-mono-video text-[.56vw] uppercase tracking-[.16em] text-[#173b3f]/55">{label}</div>}
    </div>
  );
}

export function MobileHome({ search = '', selected = 'All notes' }: { search?: string; selected?: string }) {
  const items = search ? [['A slower way to begin', 'Before reaching for a screen, leave one small margin for noticing.', 'Journal']] : [['A place for your thoughts', 'Capture the little things before they float away.', 'Personal'], ['Weekend ideas', 'Walk the lakeside trail. Try the new bakery on 5th.', 'Personal'], ['Books to return to', 'The creative act is not about waiting for inspiration.', 'Reading']];
  return (
    <div className="h-full bg-[#f7f2ea] px-[1.15vw] pb-[1vw] pt-[1.45vw] text-[#173b3f]">
      <div className="flex items-end justify-between"><div><p className="font-mono-video text-[.55vw] uppercase tracking-[.15em] text-[#f07b5f]">Your quiet corner</p><h3 className="mt-[.25vw] text-[2vw] font-extrabold tracking-[-.06em]">Notes</h3></div><div className="flex h-[2.05vw] w-[2.05vw] items-center justify-center rounded-[.7vw] bg-[#f07b5f] text-[#fffaf1]"><Plus size={13} /></div></div>
      <div className="mt-[1vw] flex h-[2.2vw] items-center gap-[.5vw] rounded-[.7vw] border border-[#173b3f]/12 bg-[#fffdf9] px-[.7vw]"><Search size={12} className="text-[#66827f]" /><span className="text-[.6vw] text-[#66827f]">{search || 'Search your notes'}</span></div>
      <div className="no-scrollbar mt-[.6vw] flex gap-[.35vw] overflow-hidden">{['All notes', 'Personal', 'Reading'].map((folder) => <span key={folder} className={`whitespace-nowrap rounded-full border px-[.55vw] py-[.38vw] text-[.5vw] ${selected === folder ? 'border-[#24545a] bg-[#24545a] text-[#fffaf1]' : 'border-[#173b3f]/12 bg-[#fffdf9] text-[#66827f]'}`}>{folder}</span>)}</div>
      <div className="mt-[1vw] flex items-baseline justify-between"><span className="text-[.85vw] font-bold">{search ? 'Search results' : selected === 'All notes' ? 'Recently written' : selected}</span><span className="font-mono-video text-[.52vw] text-[#66827f]">{items.length} notes</span></div>
      <div className="mt-[.55vw] space-y-[.45vw]">{items.map(([title, body, folder], i) => <div key={title} className="rounded-[.8vw] border border-[#173b3f]/10 bg-[#fffdf9] p-[.7vw]"><div className="flex items-center justify-between"><span className="truncate text-[.62vw] font-bold">{title}</span><Pin size={10} className={`${i === 0 ? 'fill-[#f07b5f] text-[#f07b5f]' : 'text-[#66827f]'}`} /></div><p className="mt-[.35vw] line-clamp-2 text-[.5vw] leading-[1.45] text-[#66827f]">{body}</p><div className="mt-[.55vw] flex justify-between font-mono-video text-[.42vw] uppercase tracking-[.06em] text-[#24545a]"><span>{folder}</span><span>{i === 0 ? 'now' : 'Aug 24'}</span></div></div>)}</div>
      <div className="absolute bottom-[1.2vw] right-[1.2vw] flex items-center gap-[.4vw] rounded-full bg-[#f07b5f] px-[.75vw] py-[.55vw] text-[.52vw] font-bold text-[#fffaf1]"><FileText size={10} /> New note</div>
    </div>
  );
}

export function MobileEditor({ typing = false }: { typing?: boolean }) {
  return (
    <div className="h-full bg-[#f7f2ea] px-[1.15vw] pb-[1vw] pt-[1vw] text-[#173b3f]">
      <div className="flex items-center justify-between"><div className="flex items-center gap-[.15vw] text-[.65vw] font-semibold"><span className="text-[1.2vw]">‹</span> Notes</div><div className="flex gap-[.7vw] text-[#66827f]"><Pin size={11} className="fill-[#f07b5f] text-[#f07b5f]" /><Trash2 size={10} /></div></div>
      <div className="mt-[1.2vw] text-[1.85vw] font-extrabold leading-[.98] tracking-[-.06em]">A slower way<br />to begin</div>
      <div className="mt-[.8vw] flex items-center justify-between"><div className="flex items-center gap-[.35vw] rounded-[.5vw] bg-[#d9e8de] px-[.5vw] py-[.35vw] text-[.48vw] font-semibold text-[#24545a]"><Folder size={9} /> Journal</div><span className="font-mono-video text-[.45vw] text-[#66827f]">Saved just now</span></div>
      <div className="mt-[1vw] text-[.62vw] leading-[1.72] text-[#173b3f]/72">Before reaching for a screen, leave one small margin for noticing.<br /><br />The question is not “what can I fit in?” but “what deserves my first attention?”{typing && <motion.span animate={{ opacity: [1, 0, 1] }} transition={{ repeat: Infinity, duration: .8 }} className="ml-[.1vw] inline-block h-[.72vw] w-[.05vw] bg-[#f07b5f] align-middle" />}</div>
      <div className="mt-[1.1vw] border-t border-[#173b3f]/10 pt-[.6vw]"><p className="font-mono-video text-[.45vw] uppercase tracking-[.12em] text-[#66827f]">Tags</p><div className="mt-[.35vw] flex gap-[.35vw] text-[.48vw] text-[#24545a]"><span>#personal</span><span>#reading</span></div></div>
    </div>
  );
}
