import { motion } from 'framer-motion';
import { WebEditor, WebWindow, MobileHome, MobileEditor, PhoneFrame, SceneTag, ease } from './shared';

export function Scene5() {
  return (
    <motion.section
      key="scene-5"
      className="absolute inset-0 overflow-hidden bg-[#f07b5f]"
      initial={{ clipPath: 'circle(0% at 50% 100%)' }}
      animate={{ clipPath: 'circle(100% at 50% 100%)' }}
      exit={{ clipPath: 'circle(0% at 50% 100%)' }}
      transition={{ duration: 1.05, ease }}
    >
      <motion.div className="absolute left-[33vw] top-[-21vw] h-[55vw] w-[55vw] rounded-full border border-[#fffaf1]/20" animate={{ rotate: 360 }} transition={{ duration: 25, repeat: Infinity, ease: 'linear' }} />
      <motion.div className="absolute -right-[9vw] bottom-[-19vw] h-[42vw] w-[42vw] rounded-full bg-[#d95e4b]" animate={{ scale: [1, 1.05, 1] }} transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }} />
      <div className="absolute left-[7vw] top-[6vw]"><SceneTag>Two surfaces / 05</SceneTag><motion.h2 initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: .18, duration: .85, ease }} className="font-display mt-[1.2vw] max-w-[34vw] text-[6.3vw] leading-[.82] tracking-[-.05em] text-[#fffaf1]">One quiet<br /><span className="text-[#f6d18b]">toolkit.</span></motion.h2></div>
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .8, duration: .55 }} className="ui-text absolute left-[7vw] top-[28vw] max-w-[20vw] text-[.82vw] leading-[1.5] text-[#fffaf1]/75">The same gentle rhythm, whether you are at a desk or carrying the next thought with you.</motion.p>
      <motion.div initial={{ x: -75, opacity: 0, rotate: -3 }} animate={{ x: 0, opacity: 1, rotate: -3 }} transition={{ delay: .25, duration: 1.1, ease }} className="absolute left-[31vw] top-[7vw] h-[27vw] w-[41vw]">
        <WebWindow title="Morrow — All notes" className="h-full w-full"><WebEditor saved /></WebWindow>
      </motion.div>
      <motion.div initial={{ x: 100, opacity: 0, rotate: 7 }} animate={{ x: 0, opacity: 1, rotate: 7 }} transition={{ delay: .6, duration: 1.1, ease }} className="absolute right-[7vw] bottom-[5vw] h-[21vw] w-[11vw]"><PhoneFrame label="iPhone app"><MobileHome selected="All notes" /></PhoneFrame></motion.div>
      <motion.div initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: 1.25, duration: .8, ease }} className="absolute left-[42vw] bottom-[6.8vw] h-[.1vw] w-[17vw] origin-left bg-[#f6d18b]" />
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.5 }} className="absolute left-[31vw] bottom-[5.9vw] font-mono-video text-[.55vw] uppercase tracking-[.15em] text-[#fffaf1]/70">Mac web app</motion.div>
    </motion.section>
  );
}
