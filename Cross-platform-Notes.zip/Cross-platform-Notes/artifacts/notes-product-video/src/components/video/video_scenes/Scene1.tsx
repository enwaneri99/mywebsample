import { motion } from 'framer-motion';
import { AppLogo, SceneTag, ease } from './shared';

export function Scene1() {
  return (
    <motion.section
      key="scene-1"
      className="absolute inset-0 overflow-hidden bg-[#173b3f]"
      initial={{ clipPath: 'circle(0% at 50% 50%)' }}
      animate={{ clipPath: 'circle(100% at 50% 50%)' }}
      exit={{ clipPath: 'circle(0% at 13% 84%)' }}
      transition={{ duration: 1.2, ease }}
    >
      <motion.div
        className="absolute -right-[10vw] -top-[20vw] h-[65vw] w-[65vw] rounded-full border-[.1vw] border-[#8dbfb7]/20"
        animate={{ rotate: 360, scale: [1, 1.04, 1] }}
        transition={{ rotate: { duration: 18, repeat: Infinity, ease: 'linear' }, scale: { duration: 5, repeat: Infinity, ease: 'easeInOut' } }}
      />
      <motion.div className="absolute left-[60vw] top-[18vw] h-[18vw] w-[18vw] rounded-full bg-[#215f63]" animate={{ x: [-15, 10, -15], y: [0, 18, 0] }} transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut' }} />
      <motion.div className="absolute bottom-[8vw] left-[8vw] h-[.1vw] w-[35vw] origin-left bg-[#f6d18b]" initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: .45, duration: 1.1, ease }} />
      <div className="absolute left-[7vw] top-[6vw]"><AppLogo dark /></div>
      <div className="absolute bottom-[7.8vw] left-[8vw] max-w-[42vw]">
        <SceneTag>Notes / 01</SceneTag>
        <motion.h1 initial={{ y: 50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: .32, duration: .95, ease }} className="font-display mt-[1.3vw] text-[9.8vw] leading-[.8] tracking-[-.06em] text-[#fffaf1]">A note<br /><span className="text-[#f6d18b]">can start</span><br />anywhere.</motion.h1>
        <motion.p initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.05, duration: .65, ease }} className="ui-text mt-[1.7vw] max-w-[24vw] text-[.9vw] leading-[1.45] text-[#d8e6df]/75">A quiet writing space for the ideas that arrive between everything else.</motion.p>
      </div>
      <motion.div initial={{ opacity: 0, scale: .85, rotate: -8 }} animate={{ opacity: 1, scale: 1, rotate: 4 }} transition={{ delay: .8, duration: 1.2, ease }} className="absolute right-[10vw] top-[8vw] h-[22vw] w-[31vw] rounded-[1vw] border-[.1vw] border-[#8dbfb7]/40 bg-[#215f63]/70 p-[1.2vw] shadow-[0_2vw_4vw_rgba(0,0,0,.2)]">
        <div className="h-full rounded-[.65vw] border border-[#d9e8de]/20 bg-[#f7f2ea] p-[1.2vw] text-[#173b3f]">
          <p className="font-mono-video text-[.52vw] uppercase tracking-[.16em] text-[#66827f]">A new note</p>
          <div className="font-display mt-[1.2vw] text-[2.8vw] leading-[.85]">Make room<br />for a thought.</div>
          <div className="mt-[1.1vw] h-[.07vw] w-[2vw] bg-[#f07b5f]" />
          <div className="mt-[.9vw] h-[.5vw] w-[16vw] rounded-full bg-[#173b3f]/10" /><div className="mt-[.5vw] h-[.5vw] w-[12vw] rounded-full bg-[#173b3f]/10" />
        </div>
      </motion.div>
      <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 1.25, duration: .7, ease }} className="absolute bottom-[8vw] right-[13vw] font-mono-video text-[.56vw] uppercase tracking-[.15em] text-[#d8e6df]/55">Mac web app / iPhone app</motion.div>
    </motion.section>
  );
}
