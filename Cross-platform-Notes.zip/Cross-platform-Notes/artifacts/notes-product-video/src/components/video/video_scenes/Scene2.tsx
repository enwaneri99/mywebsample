import { motion } from 'framer-motion';
import { Cursor, SceneTitle, WebEditor, WebWindow, MobileEditor, PhoneFrame, ease } from './shared';

export function Scene2() {
  return (
    <motion.section
      key="scene-2"
      className="absolute inset-0 overflow-hidden bg-[#f6f0e7]"
      initial={{ clipPath: 'polygon(0 0, 0 0, 0 100%, 0 100%)' }}
      animate={{ clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%)' }}
      exit={{ clipPath: 'polygon(100% 0, 100% 0, 100% 100%, 100% 100%)' }}
      transition={{ duration: .9, ease }}
    >
      <motion.div className="absolute -left-[15vw] bottom-[-22vw] h-[50vw] w-[50vw] rounded-full bg-[#d9e8de]" animate={{ rotate: [0, 8, 0] }} transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }} />
      <SceneTitle eyebrow="Capture / 02" className="absolute left-[7vw] top-[7vw]"><>Before it<br /><i className="text-[#f07b5f]">drifts.</i></></SceneTitle>
      <motion.p initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .6, duration: .6, ease }} className="ui-text absolute left-[7vw] top-[26vw] max-w-[18vw] text-[.82vw] leading-[1.5] text-[#66827f]">Open a fresh page. Start with the fragment, not the finished thought.</motion.p>
      <motion.div initial={{ x: 65, opacity: 0, rotate: 2 }} animate={{ x: 0, opacity: 1, rotate: 1 }} transition={{ delay: .3, duration: 1.1, ease }} className="absolute left-[29vw] top-[8vw] h-[27vw] w-[43vw]">
        <WebWindow title="Morrow — New note" className="h-full w-full">
          <WebEditor typing saved={false} />
        </WebWindow>
        <Cursor x={10} y={4} delay={1.2} />
      </motion.div>
      <motion.div initial={{ x: 70, opacity: 0, rotate: 8 }} animate={{ x: 0, opacity: 1, rotate: 7 }} transition={{ delay: .8, duration: 1.2, ease }} className="absolute right-[7vw] top-[20vw] h-[21vw] w-[11vw]">
        <PhoneFrame label="same writing ritual">
          <MobileEditor typing />
        </PhoneFrame>
      </motion.div>
      <motion.div initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: 1.2, duration: .7, ease }} className="absolute bottom-[5vw] left-[29vw] h-[.08vw] w-[38vw] origin-left bg-[#f07b5f]" />
      <div className="font-mono-video absolute bottom-[4.3vw] right-[7vw] text-[.55vw] uppercase tracking-[.15em] text-[#66827f]">Type / edit / leave it open</div>
    </motion.section>
  );
}
