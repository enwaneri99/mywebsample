import { motion } from 'framer-motion';
import { Search } from 'lucide-react';
import { WebNoteList, WebWindow, MobileHome, PhoneFrame, SceneTag, ease } from './shared';

export function Scene4() {
  return (
    <motion.section
      key="scene-4"
      className="absolute inset-0 overflow-hidden bg-[#fffaf1]"
      initial={{ clipPath: 'polygon(100% 0, 100% 0, 100% 100%, 100% 100%)' }}
      animate={{ clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%)' }}
      exit={{ clipPath: 'polygon(0 0, 0 0, 0 100%, 0 100%)' }}
      transition={{ duration: .85, ease }}
    >
      <motion.div className="absolute left-[-12vw] top-[18vw] h-[40vw] w-[40vw] rounded-full bg-[#f6d18b]/35" animate={{ x: [0, 20, 0], y: [0, -15, 0] }} transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }} />
      <div className="absolute left-[7vw] top-[7vw]"><SceneTag>Find / 04</SceneTag><motion.h2 initial={{ opacity: 0, y: 35 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .2, duration: .85, ease }} className="font-display mt-[1.2vw] max-w-[24vw] text-[6.2vw] leading-[.82] tracking-[-.05em] text-[#173b3f]">Search<br /><span className="text-[#f07b5f]">the whole</span><br />thread.</motion.h2></div>
      <motion.p initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .8, duration: .5, ease }} className="ui-text absolute left-[7vw] top-[30.5vw] max-w-[18vw] text-[.8vw] leading-[1.5] text-[#66827f]">Titles, words and tags stay close enough to be found in one breath.</motion.p>
      <motion.div initial={{ scale: .85, opacity: 0, x: -35 }} animate={{ scale: 1, opacity: 1, x: 0 }} transition={{ delay: .28, duration: 1.1, ease }} className="absolute left-[27vw] top-[7vw] h-[29vw] w-[49vw]">
        <WebWindow title="Morrow — Search" className="h-full w-full">
          <div className="flex min-w-0 flex-1 flex-col bg-[#faf7f1]">
            <div className="flex h-[3vw] items-center border-b border-[#173b3f]/10 px-[1vw]"><div className="flex h-[1.55vw] w-[19vw] items-center gap-[.45vw] rounded-[.45vw] border border-[#8dbfb7] bg-[#fffdf9] px-[.55vw]"><Search size={10} className="text-[#66827f]" /><span className="font-mono-video text-[.55vw] text-[#173b3f]">attention</span><motion.span animate={{ opacity: [1, 0, 1] }} transition={{ repeat: Infinity, duration: .9 }} className="h-[.7vw] w-[.05vw] bg-[#f07b5f]" /></div><span className="ml-auto font-mono-video text-[.5vw] uppercase tracking-[.12em] text-[#66827f]">03 notes</span></div>
            <WebNoteList search="attention" active="A slower way to begin" />
          </div>
        </WebWindow>
      </motion.div>
      <motion.div initial={{ x: 60, opacity: 0, rotate: 8 }} animate={{ x: 0, opacity: 1, rotate: 8 }} transition={{ delay: .75, duration: 1.1, ease }} className="absolute right-[8vw] bottom-[4.8vw] h-[19vw] w-[10vw]"><PhoneFrame label="folders at a glance"><MobileHome selected="Personal" search="attention" /></PhoneFrame></motion.div>
      <motion.div initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: .95, duration: 1.15, ease }} className="absolute bottom-[4.6vw] left-[27vw] h-[.08vw] w-[36vw] origin-left bg-[#215f63]" />
    </motion.section>
  );
}
