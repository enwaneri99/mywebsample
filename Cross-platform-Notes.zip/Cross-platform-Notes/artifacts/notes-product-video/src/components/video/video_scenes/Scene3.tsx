import { motion } from 'framer-motion';
import { Cursor, SceneTag, WebEditor, WebWindow, MobileEditor, PhoneFrame, ease } from './shared';

export function Scene3() {
  return (
    <motion.section
      key="scene-3"
      className="absolute inset-0 overflow-hidden bg-[#215f63]"
      initial={{ clipPath: 'circle(0% at 84% 74%)' }}
      animate={{ clipPath: 'circle(100% at 84% 74%)' }}
      exit={{ clipPath: 'circle(0% at 84% 74%)' }}
      transition={{ duration: 1.05, ease }}
    >
      <motion.div className="absolute right-[-18vw] top-[-18vw] h-[54vw] w-[54vw] rounded-full border border-[#f6d18b]/25" animate={{ rotate: -360 }} transition={{ duration: 24, repeat: Infinity, ease: 'linear' }} />
      <motion.div className="absolute bottom-[-12vw] left-[37vw] h-[28vw] w-[28vw] rounded-full bg-[#2b7776]" animate={{ scale: [1, 1.08, 1] }} transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }} />
      <div className="absolute left-[7vw] top-[7vw]"><SceneTag>Shape / 03</SceneTag><motion.h2 initial={{ y: 35, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: .22, duration: .8, ease }} className="font-display mt-[1.2vw] max-w-[27vw] text-[6.3vw] leading-[.84] tracking-[-.05em] text-[#fffaf1]">Let the<br /><span className="text-[#f6d18b]">details</span><br />find their place.</motion.h2></div>
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .85, duration: .6 }} className="ui-text absolute left-[7vw] top-[30vw] max-w-[20vw] text-[.8vw] leading-[1.5] text-[#d8e6df]/72">Folders, tags and a pin keep the useful things close without turning the page into a filing cabinet.</motion.p>
      <motion.div initial={{ scale: .9, x: 75, opacity: 0, rotate: -2 }} animate={{ scale: 1, x: 0, opacity: 1, rotate: -2 }} transition={{ delay: .15, duration: 1.1, ease }} className="absolute left-[34vw] top-[6vw] h-[30vw] w-[41vw]">
        <WebWindow title="Morrow — Journal / A slower way to begin" className="h-full w-full"><WebEditor details saved /></WebWindow>
        <Cursor x={14} y={10} delay={1.1} />
      </motion.div>
      <motion.div initial={{ y: 80, opacity: 0, rotate: 5 }} animate={{ y: 0, opacity: 1, rotate: 5 }} transition={{ delay: .7, duration: 1, ease }} className="absolute bottom-[3.5vw] right-[9vw] h-[18vw] w-[10vw]">
        <PhoneFrame label="saved on device"><MobileEditor /></PhoneFrame>
      </motion.div>
      <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 1.4, duration: .7, ease }} className="absolute bottom-[5.1vw] left-[7vw] flex items-center gap-[.6vw] font-mono-video text-[.55vw] uppercase tracking-[.14em] text-[#f6d18b]"><span className="h-[.45vw] w-[.45vw] rounded-full bg-[#8dbfb7]" /> Autosave stays out of the way</motion.div>
    </motion.section>
  );
}
