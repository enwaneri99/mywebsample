import { motion } from 'framer-motion';
import { AppLogo, MobileHome, PhoneFrame, SceneTag, WebWindow, WebNoteList, ease } from './shared';

export function Scene6() {
  return (
    <motion.section
      key="scene-6"
      className="absolute inset-0 overflow-hidden bg-[#173b3f]"
      initial={{ clipPath: 'polygon(0 0, 0 100%, 100% 100%, 0 100%)' }}
      animate={{ clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%)' }}
      exit={{ opacity: 0, scale: 1.08 }}
      transition={{ duration: 1.1, ease }}
    >
      <motion.div className="absolute left-[-8vw] top-[-25vw] h-[65vw] w-[65vw] rounded-full border border-[#8dbfb7]/18" animate={{ rotate: -360, x: [0, 18, 0] }} transition={{ rotate: { duration: 28, repeat: Infinity, ease: 'linear' }, x: { duration: 9, repeat: Infinity, ease: 'easeInOut' } }} />
      <motion.div className="absolute right-[-18vw] bottom-[-28vw] h-[62vw] w-[62vw] rounded-full bg-[#215f63]" animate={{ scale: [1, 1.05, 1] }} transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut' }} />
      <div className="absolute left-[7vw] top-[6vw]"><AppLogo dark /></div>
      <div className="absolute left-[7vw] top-[14vw]"><SceneTag>Notes / 06</SceneTag><motion.h2 initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .22, duration: 1, ease }} className="font-display mt-[1.3vw] max-w-[32vw] text-[7.4vw] leading-[.82] tracking-[-.055em] text-[#fffaf1]">Keep the<br /><span className="text-[#f6d18b]">thought.</span></motion.h2><motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .95, duration: .6 }} className="ui-text mt-[1.5vw] max-w-[21vw] text-[.84vw] leading-[1.5] text-[#d8e6df]/74">A calm place for what matters enough to remember.</motion.p></div>
      <motion.div initial={{ opacity: 0, x: 80, rotate: 4 }} animate={{ opacity: .95, x: 0, rotate: 4 }} transition={{ delay: .45, duration: 1.2, ease }} className="absolute left-[39vw] top-[8vw] h-[24vw] w-[37vw] opacity-90">
        <WebWindow title="Morrow — A place for thoughts" className="h-full w-full"><WebNoteList active="A slower way to begin" /></WebWindow>
      </motion.div>
      <motion.div initial={{ opacity: 0, x: 100, rotate: 8 }} animate={{ opacity: 1, x: 0, rotate: 8 }} transition={{ delay: .85, duration: 1.1, ease }} className="absolute right-[9vw] bottom-[4vw] h-[19vw] w-[10vw]"><PhoneFrame label="Notes for iPhone"><MobileHome /></PhoneFrame></motion.div>
      <motion.div initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: 1.5, duration: .75, ease }} className="absolute bottom-[6.4vw] left-[7vw] h-[.1vw] w-[23vw] origin-left bg-[#f07b5f]" />
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.6, duration: .6 }} className="font-mono-video absolute bottom-[5.5vw] left-[7vw] text-[.54vw] uppercase tracking-[.17em] text-[#f6d18b]">Morrow / make room for what matters</motion.p>
    </motion.section>
  );
}
