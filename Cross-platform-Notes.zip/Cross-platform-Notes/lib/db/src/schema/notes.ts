import { createInsertSchema } from "drizzle-zod";
import { boolean, index, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const notesTable = pgTable(
  "notes",
  {
    id: text("id").primaryKey(),
    title: text("title").notNull(),
    content: text("content").notNull(),
    folder: text("folder").notNull(),
    tags: text("tags").array().notNull().default([]),
    pinned: boolean("pinned").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    updatedAtIndex: index("notes_updated_at_idx").on(table.updatedAt),
    folderIndex: index("notes_folder_idx").on(table.folder),
  }),
);

export const insertNoteSchema = createInsertSchema(notesTable).omit({
  createdAt: true,
  updatedAt: true,
});

export type InsertNote = z.infer<typeof insertNoteSchema>;
export type Note = typeof notesTable.$inferSelect;