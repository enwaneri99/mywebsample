import { db, pool } from "./index";
import { notesTable, type InsertNote } from "./schema";

const starterNotes: InsertNote[] = [
  {
    id: "seed-morning-pages",
    title: "A slower way to begin",
    content:
      "Before reaching for a screen, leave one small margin for noticing.\n\nThe question is not “what can I fit in?” but “what deserves my first attention?” A good day might begin with one page, one glass of water, and a clear place to put the thoughts that arrive.",
    folder: "Journal",
    tags: ["personal"],
    pinned: true,
  },
  {
    id: "seed-reading-list",
    title: "Books to return to",
    content:
      "The best reading list is not a queue. It is a little map of the questions I am carrying.\n\n— The Art of Noticing\n— Braiding Sweetgrass\n— A Field Guide to Getting Lost",
    folder: "Ideas",
    tags: ["reading"],
    pinned: false,
  },
  {
    id: "seed-sunday-project",
    title: "Sunday project notes",
    content:
      "Make the first version small enough to finish in one sitting.\n\nWhat would still be useful if the clever parts disappeared? Keep the edges soft. Leave a visible trail back to the original question.",
    folder: "Work",
    tags: ["project", "reading"],
    pinned: false,
  },
  {
    id: "welcome",
    title: "A place for your thoughts",
    content:
      "Capture the little things before they float away.\n\nThis is your quiet corner for ideas, lists, and everything in between.",
    folder: "Personal",
    tags: ["welcome"],
    pinned: true,
  },
  {
    id: "weekend",
    title: "Weekend ideas",
    content:
      "• Walk the lakeside trail\n• Try the new bakery on 5th\n• Call Mum Sunday morning",
    folder: "Personal",
    tags: ["ideas"],
    pinned: false,
  },
  {
    id: "reading",
    title: "Books to return to",
    content:
      "The creative act is not about waiting for inspiration. It is about making room for it.",
    folder: "Reading",
    tags: ["books", "quotes"],
    pinned: false,
  },
];

await db.insert(notesTable).values(starterNotes).onConflictDoNothing();
await pool.end();